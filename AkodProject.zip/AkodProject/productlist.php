<!DOCTYPE html>
<html lang="en">

<head>
<!-- Meta -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<meta name="keywords" content="MediaCenter, Template, eCommerce">
<meta name="robots" content="all">
<title>AKOD TRADING ENTERPRISE | Cereals | Mayonnaise | Grains | Flour Meals | Energy Food Drinks | Vegetable Oil | Flavours | Noodles | Sugar </title>

<!-- Bootstrap Core CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">

<!-- Customizable CSS -->
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/css/blue.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.transitions.css">
<link rel="stylesheet" href="assets/css/animate.min.css">
<link rel="stylesheet" href="assets/css/rateit.css">
<link rel="stylesheet" href="assets/css/bootstrap-select.min.css">

<!-- Icons/Glyphs -->
<link rel="stylesheet" href="assets/css/font-awesome.css">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Barlow:200,300,300i,400,400i,500,500i,600,700,800" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
    #products {
       /* height:800px;*/
        margin-top:2%;
        margin-bottom:2%;
        z-index:0;
        background-color:white;
        height:500px;
        overflow-y: scroll; 
    }
    #prodImage{
        margin-top:2%;
        width:200px;
    }
    #descrDetails{
        display:none;
    }
    .table {
        width:100%;
        border: 2px double blue;
    }
    #products tr, th, td {
        text-align: left;
        padding: 8px;
        border: 1px solid blue;
        border-collapse: collapse;
    }
    .table td:nth-child(even),th:nth-child(even){
        background-color:lightgreen;
    }
    #product{
        cursor:pointer;
        height:500px;
        overflow-y: scroll;

    }
    #descr{
        font-style:italic;
    }
    #decrDetails{
        font-weight:bold;
        display:none;
    }
    #decrimage{
        display:none;
    }
    #cartItems{
        top:10%;
        left: 15%;
        index-z: 3;
        width:80%;
        position:absolute;
        display:none;
        
    }
    #orderTable{
        background-color:white;
    }
    #orderTable td:nth-child(even), th:nth-child(even){
        background-color:white;
    }
    #submitBtn{
        font-size:18px; float: right;
    }
    #footer{
        height:400px;
        bottom:0;
        /*position:fixed;*/
    }
    @media only screen and (max-width: 700px){
            #footer{
                bottom: -700px; 
                left:0;
                right:0;
                position:absolute;
            }
        }
    }
    
</style>
    
</head>
<body class="cnt-home" onload="loadPage(); loadProductPage();">
    <!--- header -->
    <?php 
        include('src/header.php');
    ?>
    <!-- database connection -->
    <?php
        //compose the where clause
        $whereclause = "";
        $empty = true;

        if(isset($_GET["productCategoryId"])){
            $productId1 = $_GET["productCategoryId"];  
            $whereclause = $whereclause . "productCatId = '" . $productId1 . "'";
            $empty = false;
        }

        if(isset($_GET["productCategoryId1"])){
            $productId1 = $_GET["productCategoryId1"];  
            $whereclause = $whereclause . "productCatId = '" . $productId1 . "'";
            $empty = false;
        }
        if(isset($_GET["productCategoryId2"])){
            $productId2 = $_GET["productCategoryId2"];
            if($empty==false){  
                $whereclause =$whereclause . " or productCatId='" . $productId2 . "'";
            }
            else{
                $whereclause =$whereclause . "productCatId = '" . $productId2 . "'";
                $empty = false;
            }
        }
        if(isset($_GET["productCategoryId3"])){
            $productId3 = $_GET["productCategoryId3"];  
            if($empty == false){
                $whereclause =$whereclause . " or productCatId = '" . $productId3 . "'";
            }
            else{
                $whereclause =$whereclause . "productCatId = '" . $productId3 . "'";
                $empty = false;
            }
        }
        if(isset($_GET["productCategoryId4"])){
            $productId4 = $_GET["productCategoryId4"];  
            if($empty == false){
                $whereclause =$whereclause . " or productCatId = '" . $productId4 . "'";
            }
            else{
                $whereclause =$whereclause . "productCatId = '" . $productId4 . "'";
                $empty = false;
            }
        }
        if(isset($_GET["productCategoryId5"])){
            $productId5 = $_GET["productCategoryId5"];  
            if($empty == false){
                $whereclause =$whereclause . " or productCatId = '" . $productId5 . "'";
            }
            else{
                $whereclause =$whereclause . "productCatId = '" . $productId5 . "'";
                $empty = false;
            }
        }
        if(isset($_GET["productCategoryId6"])){
            $productId6 = $_GET["productCategoryId6"];  
            if($empty == false){
                $whereclause =$whereclause . " or productCatId = '" . $productId6 . "'";
            }
            else{
                $whereclause =$whereclause . "productCatId = '" . $productId6 . "'";
                $empty = false;
            }
        }
        if(isset($_GET["productCategoryId7"])){
            $productId7 = $_GET["productCategoryId7"];  
            if($empty == false){
                $whereclause =$whereclause . " or productCatId = '" . $productId7 . "'";
            }
            else{
                $whereclause =$whereclause . "productCatId = '" . $productId7 . "'";
                $empty = false;
            }
        }
        if(isset($_GET["productCategoryId8"])){
            $productId8 = $_GET["productCategoryId8"];  
            if($empty == false){
                $whereclause =$whereclause . " or productCatId = '" . $productId8 . "'";
            }
            else{
                $whereclause =$whereclause . "productCatId = '" . $productId8 . "'";
                $empty = false;
            }
        }
        if(isset($_GET["productCategoryId9"])){
            $productId9 = $_GET["productCategoryId9"];  
            if($empty == false){
                $whereclause =$whereclause . " or productCatId = '" . $productId9 . "'";
            }
            else{
                $whereclause =$whereclause . "productCatId = '" . $productId9 . "'";
                $empty = false;
            }
        }
        if(isset($_GET["productCategoryId10"])){
            $productId10 = $_GET["productCategoryId10"];  
            if($empty == false){
                $whereclause =$whereclause . " or productCatId = '" . $productId10 . "'";
            }
            else{
                $whereclause =$whereclause . "productCatId = '" . $productId10 . "'";
                $empty = false;
            }
        }
        if(isset($_GET["productCategoryId11"])){
            $productId11 = $_GET["productCategoryId11"];  
            if($empty == false){
                $whereclause =$whereclause . " or productCatId = '" . $productId11 . "'";
            }
            else{
                $whereclause =$whereclause . "productCatId = '" . $productId11 . "'";
                $empty = false;
            }
        }
        echo $whereclause;
        include('assets/database/databaseconnection.php');
        $sql = "select * from producttbl where $whereclause";
        //echo "<div> The Sql is: ". $sql ."</div>";
        $result = $conn->query($sql);
    ?>
    
    <div class = "container-fluid" id="body">
        <div class = "row" style = "height: 600px; overflow-y:scroll;">
            <div class = "col-md-9 col-sm-12 col-xs-12" id = "products">
                <h3>Product Listing <span style = "font-style:italic; font-size:14px">(Select Items to add to cart)</span></h3>
                <?php 
                    
                    //display product table
                    echo "<table class = 'table'>";
                    echo "<thead>";
                    echo "<tr>";
                    echo "<th style = 'width:4%'>S/N</th>";
                    echo "<th style = 'width:6%'>Select<br>Item</th>";
                    echo "<th style = 'width:10%'>Product ID</th>";
                    echo "<th style = 'width:10%'>Category ID</th>";
                    echo "<th style = 'width:10%'>Product Name</th>";
                    echo "<th style = 'width:10%'>Brand Name</th>";
                    echo "<th style = 'width:20%'>Product Description</th>";
                    echo "<th style = 'width:10%'>Net Weight</th>";
                    echo "<th style = 'width:10%'>Wholesale<br> Price</th>";
                    echo "<th style = 'width:10%'>Retail<br> Price</th>";
                    echo "</tr>";
                    echo "</thead>";
                    echo "<tbody>";
                    $i=0;
                  //  echo "Passed Category: ". $_GET["type"]."<br>";
                    if($result->num_rows>0){
                        while($row = $result->fetch_assoc()){
                            //echo "Database Categories: ". $row["productCatId"]."<br>";
                         //   if($_GET["productCategoryId1"]==$row["productCatId"]){
                                $r = $i;
                                $t = "tooltip".$i;
                                $selected = $i;
                                $imageName = $row["productId"];
                                $wholeSalePrice = $row["WholeSalePrice"];
                                $retailSalePrice = $row["RetailSalePrice"];
                                $productName = $row["ProductName"];
                                $brandName = $row["BrandName"];
                                $productDescr = $row["ProductDescription"];
                                echo "<tr>";
                                    echo "<td>";
                                        echo ++$i .".";
                                    echo "</td>";
                                    echo "<td>";
                                        echo "<input id='$selected' type = 'checkbox' name ='".$row["productId"]."'
                                         productName = '$productName' brandName = '$brandName' productDescr = '$productDescr'
                                         wholeSalePrice = '$wholeSalePrice' retailSalePrice = '$retailSalePrice' 
                                         onclick='addToCart(id);'>";
                                    echo "</td>"; 
                                    echo "<td id = '$r'  onmouseover='showToolTip(id)'; onmouseout = 'closeToolTip(id);'>";
                                        echo $row["productId"];
                                        echo "<div id = '$t' image = '$imageName' wholeSalePrice = '$wholeSalePrice' retailSalePrice = '$retailSalePrice' 
                                        style = 'display:none;cursor:pointer; background-color: #20B2AA; color: white; padding:5px;' onclick = 'showProductDetails(id);'>
                                           Click to view Image
                                        </div>";
                                    echo "</td>";
                                    echo "<td>";
                                        echo $row["productCatId"];
                                    echo "</td>";
                                    echo "<td>";
                                        echo $row["ProductName"];
                                    echo "</td>";
                                    echo "<td>";
                                        echo $row["BrandName"];
                                    echo "</td>";
                                    echo "<td>";
                                        echo $row["ProductDescription"];
                                    echo "</td>";
                                    echo "<td>";
                                        echo $row["ProductNetWeight"];
                                    echo "</td>";
                                    echo "<td>";
                                        echo $row["WholeSalePrice"];
                                    echo "</td>";
                                    echo "<td>";
                                        echo $row["RetailSalePrice"];
                                    echo "</td>";
                                echo "</tr>";
                                // retrieve the category name
                                $sql_cat = "select * from categorytbl";
                                $result_cat = $conn->query($sql_cat);
                                if($result_cat->num_rows>0){
                                    while($row_cat = $result_cat->fetch_assoc()){
                                        if ($row_cat["ProductCatId"]==$row["productCatId"]){
                                            $selectedCategory = $row_cat["CategoryName"];
                                            echo "<form><input id='categoryName' type = 'hidden' value ='$selectedCategory'></form>";
                                        }
                                    }
                                }
                            }
                          /*  else{
                                echo "<script>alert('selected product no longer in stock)'</script>";
                            }
                        }*/
                    }
                    else{
                        echo "No Products listed on Database";
                    }
                    echo "</tr>";
                    echo "</tbody>";
                    $conn->close(); 
                ?> 
                </table>
                <form id = "cartItems" action = "cartPage.php" method="post">
                    <table id = "orderTable">
                        <tr>
                            <th colspan ="4"></th>
                            <th colspan = "3" style = "background-color:darkgray" >
                                <button style="font-size:18px; float: right">
                                    Proceed To Cart<i class="fa fa-shopping-cart"></i>
                                </button>
                            </th>
                        </tr>
                        <tr>
                            <th>S/No</th>
                            <th>Product Name</th>
                            <th>Brand Name</th>
                            <th>PURCHASE TYPE</th>
                            <th>Price</th>
                            <th>Quantity</th>
                            <th>Amount</th>
                        </tr>
                    </table>
                   <input type = "hidden" id="grandTotal" value="0">
                </form>
                
            </div>
            
            <div class = "col-md-3 col-sm-12 col-xs-12" style="height:400px;">
                <div class = "container">
                    <div class = "row">
                        <div class = "col" id="descrImg">
                            <img id = "prodImage" src ="">
                        </div>
                        <div class = "col" id="descrDetails">
                              <p>Whole Sale Price: &#8358;<span id="wprice"></span></p>  
                              <p>Retail Sale Price: &#8358;<span id="rprice"></span></p>  
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div> 
    
    <div class="container-fluid" id="footer">
        <div class = "row">
            <div class = "col-md-12 col-sm-12 col-xs-12">
                <?php include ("src/footer.php"); ?>
            </div>
        </div>
    </div>
    <script src="assets/js/loadPage.js"></script>
    <script> 
          
    </script>

</body>
</html>