-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2021 at 10:20 PM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `akoddb`
--

-- --------------------------------------------------------

--
-- Table structure for table `cartitems`
--

CREATE TABLE `cartitems` (
  `cartId` varchar(10) NOT NULL,
  `UserID` varchar(10) NOT NULL,
  `Date` date NOT NULL,
  `CartStatus` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categorytbl`
--

CREATE TABLE `categorytbl` (
  `ProductCatId` text NOT NULL,
  `CategoryName` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categorytbl`
--

INSERT INTO `categorytbl` (`ProductCatId`, `CategoryName`) VALUES
('AkodCat1', 'Grains & Cereals'),
('AkodCat2', 'Vegetable Oil'),
('AkodCat3', 'Seasonings & Flavours'),
('AkodCat4', 'Pastas & Noodles'),
('AkodCat5', 'Tomatoes Pastes & Mixes'),
('AkodCat6', 'Energy Food Drinks'),
('AkodCat7', 'Flour Meals'),
('AkodCat8', 'Pasteries & Oven Products'),
('AkodCat9', 'Frozen Food'),
('AkodCat10', 'Sugars & Mayonnaise'),
('AkodCat11', 'Live Feed');

-- --------------------------------------------------------

--
-- Table structure for table `producttbl`
--

CREATE TABLE `producttbl` (
  `productId` varchar(15) NOT NULL,
  `productCatId` varchar(15) NOT NULL,
  `ProductName` text NOT NULL,
  `BrandName` text NOT NULL,
  `ProductDescription` text NOT NULL,
  `ProductNetWeight` text NOT NULL,
  `WholeSalePrice` double NOT NULL,
  `RetailSalePrice` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `producttbl`
--

INSERT INTO `producttbl` (`productId`, `productCatId`, `ProductName`, `BrandName`, `ProductDescription`, `ProductNetWeight`, `WholeSalePrice`, `RetailSalePrice`) VALUES
('AkodProd001', 'AkodCat04', 'Instant Noodles', 'Golden Penny', 'Goat Meat Pepper Soup Flavour', '70g', 0, 0),
('AkodProd002', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Regular Chicken', '70g', 0, 0),
('AkodProd003', 'AkodCat04', 'Instant Noodles', 'Golden Penny', 'Jollof Chicken Flavour', '70g', 0, 0),
('AkodProd004', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Onion Chicken', '70g', 0, 0),
('AkodProd005', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Regular Chicken (Big Daddy)', '70g', 0, 0),
('AkodProd006', 'AkodCat04', 'Instant Noodles', 'Minimie', 'Slurpy Chicken Flavour', '', 0, 0),
('AkodProd007', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Limited Edition (Color)', '70g', 0, 0),
('AkodProd008', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Regular Chicken Noodles', '100g', 0, 0),
('AkodProd009', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Oriental Fried Noodles', '100g', 0, 0),
('AkodProd0091', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Chicken Pepper Soup', '100g', 0, 0),
('AkodProd0092', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Super Pack Chicken Flavour', '120g', 0, 0),
('AkodProd0093', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Super Pack Onion Chicken', '120g', 0, 0),
('AkodProd0094', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Cray Fish', '180g', 0, 0),
('AkodProd0095', 'AkodCat04', 'Instant Noodle', 'Indomie', 'Chicken Hungryman', '180g', 0, 0),
('AkodProd0096', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Belle Full Pack', '280g', 0, 0),
('AkodProd0097', 'AkodCat04', 'Instant Noodles', 'Indomie', 'Onion Belle Full Pack', '280g', 0, 0),
('AkodProd011', 'AkodCat02', 'Vegetable Oil', 'Power Oil', '', '60 x 70ml', 0, 0),
('AkodProd012', 'AkodCat02', 'Vegetable Oil', 'Devon Kings', '', '4 x 5 ltr', 0, 0),
('AkodProd013', 'AkodCat02', 'Vegetable Oil', 'Mamador', 'Pure Vegetable Oil', '4 x 2.5ltr', 0, 0),
('AkodProd014', 'AkodCat02', 'Vegetable Oil', 'Devon Kings', '', '25ltr', 0, 0),
('AkodProd015', 'AkodCat02', 'Vegetable Oil', 'Devon Kings', '', '6 x 2l', 0, 0),
('AkodProd016', 'AkodCat02', 'Vegetable oil', 'Power Oil', '', '40 x 140ml', 0, 0),
('AkodProd017', 'AkodCat02', 'Vegetable Oil', 'Power Oil', '', '12 x 750ml', 0, 0),
('AkodProd018', 'AkodCat02', 'Vegetable oil', 'Power Oil', '', '8 x 1.4l', 0, 0),
('AkodProd019', 'AkodCat02', 'Vegetable Oil', 'Power Oil', '', '6 x 3l', 0, 0),
('AkodProd020', 'AkodCat02', 'Vegetable oil', 'Power Oil', '', '4 x 4.5l', 0, 0),
('AkodProd021', 'AkodCat03', 'Dried Thyme', 'Gino', 'Satchets', '3g x 210', 0, 0),
('AkodProd022', 'AkodCat03', 'Tomatoes Mix', 'Gino', 'Satchets', '65g x 50', 0, 0),
('AkodProd023', 'AkodCat03', 'Pepper & Onion Paste', 'Gino', 'Satchets', '65g x 50', 0, 0),
('AkodProd024', 'AkodCat03', 'Seasoning Cubes', 'Gino', 'Chicken Flavour', '', 0, 0),
('AkodProd025', 'AkodCat03', 'Seasoning Cubes', 'Maggi', 'Star Seasoning', '', 0, 0),
('AkodProd026', 'AkodCat03', 'Seasoning Cubes', 'Maggi', 'Chicken Flavour', '', 0, 0),
('AkodProd031', 'AkodCat10', 'Sugar', 'Golden Penny', 'White Cubes', '500g', 0, 0),
('AkodProd041', 'AkodCat01', 'Cereals', 'Amazing Day', 'Maize, Soya & Cassava Tasty Cereals', '100 x 50g', 0, 0),
('AkodProd0411', 'AkodCat01', 'Cereals', 'Amazing Day', 'Maize, Soya & Cassava Tasty Cereals', '1 x 1kg', 0, 0),
('AkodProd042', 'AkodCat01', 'Cereals', 'Nestle', 'Golden Morn', '12 x 450g', 0, 0),
('AkodProd043', 'AkodCat01', 'Rice', '', 'Foreign Rice', '50kg', 0, 0),
('AkodProd044', 'AkodCat01', 'Rice', '', 'Local Rice', '50kg', 0, 0),
('AkodProd045', 'AkodCat01', 'Rice', '', 'Long Grains', '50kg', 0, 0),
('AkodProd046', 'AkodCat01', 'Rice', '', 'Short Grains', '50kg', 0, 0),
('AkodProd051', 'AkodCat10', 'Mayonnaise', 'Bama', '', '12 x 32 fl.oz (946ml)', 0, 0),
('AkodProd052', 'AkodCat10', 'Mayonnaise', 'Jago', '', '12 x 30 oz (887ml)', 0, 0),
('AkodProd061', 'AkodCat06', 'Milo', 'Nestle', 'Energy Food Drink', '240 x 20g', 0, 0),
('AkodProd062', 'AkodCat06', 'Milo', 'Nestle', 'Energy Cubes', '24 x 100 x 2.75g', 0, 0),
('AkodProd063', 'AkodCat06', 'Milo', 'Nestle', 'Energy Food Drink', '12 x 500g', 0, 0),
('AkodProd064', 'AkodCat06', 'Milo', 'Nestle', 'Energy Food Drink', '6 x 1kg', 0, 0),
('AkodProd071', 'AkodCat07', 'Semovita', 'Golden Penny', 'Flour Meals', '10 x 1kg', 0, 0),
('AkodProd072', 'AkodCat07', 'Semolina', 'Honeywell', 'Flour Meal', '5kg', 0, 0),
('AkodProd073', 'AkodCat07', 'Semovita', 'Golden Penny', 'Flour Meals', '10kg', 0, 0),
('AkodProd074', 'AkodCat07', 'Semolina', 'Honeywell', 'Whole Wheat Meal', '10kg', 0, 0),
('AkodProd081', 'AkodCat08', 'Bread', 'Pariola', 'Loaf', '', 0, 0),
('AkodProd091', 'AkodCat09', 'Chicken', '', 'Frozen Food', '', 0, 0),
('AkodProd092', 'AkodCat09', 'Turkey', '', '', '', 0, 0),
('AkodProd093', 'AkodCat09', 'Fish', '', '', '', 0, 0),
('AkodProd101', 'AkodCat11', 'Cows', '', '', '', 0, 0),
('AkodProd102', 'AkodCat11', 'Goats', '', '', '', 0, 0),
('AkodProd103', 'AkodCat11', 'Chicken', '', 'Live Chicken', '', 0, 0),
('AkodProd104', 'AkodCat11', 'Turkey', '', 'Live Turkeys', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `userstbl`
--

CREATE TABLE `userstbl` (
  `sno` int(11) NOT NULL,
  `UserID` varchar(10) NOT NULL,
  `FullName` varchar(50) NOT NULL,
  `Phone` varchar(20) NOT NULL,
  `Email` varchar(50) NOT NULL,
  `UserType` varchar(10) NOT NULL,
  `Password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userstbl`
--

INSERT INTO `userstbl` (`sno`, `UserID`, `FullName`, `Phone`, `Email`, `UserType`, `Password`) VALUES
(1, 'admin', 'Steve Omiunu', '+2347065956369', 'admin@gentleflakes.com.ng', 'Developer', 'gfcl');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cartitems`
--
ALTER TABLE `cartitems`
  ADD PRIMARY KEY (`cartId`),
  ADD UNIQUE KEY `cartId` (`cartId`),
  ADD UNIQUE KEY `UserID` (`UserID`);

--
-- Indexes for table `producttbl`
--
ALTER TABLE `producttbl`
  ADD PRIMARY KEY (`productId`);

--
-- Indexes for table `userstbl`
--
ALTER TABLE `userstbl`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `UserID` (`UserID`),
  ADD KEY `sNo` (`sno`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `userstbl`
--
ALTER TABLE `userstbl`
  MODIFY `sno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
