<!DOCTYPE html>
<html lang="en">

<head>
<!-- Meta -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<meta name="keywords" content="MediaCenter, Template, eCommerce">
<meta name="robots" content="all">
<title>AKOD TRADING ENTERPRISE | Cereals | Mayonnaise | Grains | Flour Meals | Energy Food Drinks | Vegetable Oil | Flavours | Noodles | Sugar </title>

<!-- Bootstrap Core CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">

<!-- Customizable CSS -->
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/css/blue.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.transitions.css">
<link rel="stylesheet" href="assets/css/animate.min.css">
<link rel="stylesheet" href="assets/css/rateit.css">
<link rel="stylesheet" href="assets/css/bootstrap-select.min.css">
<link rel="stylesheet" href="assets/css/login.css">
<!--<link rel="stylesheet" href="assets/css/register.css"> -->

<!-- Icons/Glyphs -->
<link rel="stylesheet" href="assets/css/font-awesome.css">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Barlow:200,300,300i,400,400i,500,500i,600,700,800" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<style>
    hr{
        border-color:blue;
        border-width:2px;
    }
    #products-menu {
        margin: 15px 10px 5px 10px;
        padding: 20px; 
        height: 450px; 
        background-color:#d9ff66
    }
    #products-menu li{
        margin-left:20px; margin-top:5px;
        font-weight:bold;
    }
    #subProducts li{
        font-weight: normal;
    }
    #subProducts hr{
        border-width:1px;
    }
    #viewByCategory, #viewByProductName, #managePrices, #restockProducts {
        height: 450px;
        margin: 15px 10px 5px 10px;
        padding: 10px; 
        background-color:white;
        display:none;
    }
    #adminHome{
        height: 450px;
        margin: 15px 10px 5px 10px;
        padding: 20px; 
        background-color:blue;
        color:white;
        display:block;
    }

</style>
</head>

<body class="cnt-home" onload="loadPage();">
<?php 
    include("src/header.php");
    include("src/databaseconnection.php");
?>
<div class = "container-fluid" style="height: 500px;">
   
</div>
<?php include("src/footer.php"); ?>
</body>
</html>