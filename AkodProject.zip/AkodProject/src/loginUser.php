<?php
    print_r($_POST);
    
    if(isset($_POST["submit"])){
        $myUserName = $_POST["loggedusername"];
        $myPassword = $_POST["loggedpassword"];
        include ("databaseconnection.php");

        $sql1 = "select * from userstbl where UserID ='$myUserName' and Password='$myPassword'";
        $result = $conn->query($sql1);
        if($result->num_rows>0){
            while($row=$result->fetch_assoc()){
                /*      echo "Database User ID: ".$row["UserID"];
                echo "Database Password: ".$row["Password"]; */
                $phone = $_SESSION["phone"] = $row["Phone"];
                $email = $_SESSION["email"] =  $row["Email"];
                $fullName = $_SESSION["fullName"] =  $row["FullName"];
                $userType = $_SESSION["userType"] =  $row["UserType"];
                echo "<br><input type='hidden' name= 'myUserName' id='myUserName' value = '$myUserName'>";
                echo "<br><input type='hidden' name= 'myPhone' id='myPhone' value = '$phone'>";
                echo "<br><input type='hidden' name= 'myEmail' id='myEmail' value = '$email'>";
                echo "<br><input type='hidden' name= 'myFullName' id= 'myFullName' value = '$fullName'>";
                echo "<br><input type='hidden' name= 'myUserType' id='myUserType' value = '$userType'>"; 

                //edit usertbl status

                $sql_update_user = "update userstbl set Status = 'Active' where userID = '$myUserName'";
                $result_update_user = $conn->query($sql_update_user);
                if(!$result_update_user){
                    echo $conn->error;
                }
                else{
                    echo $fullName." logged in";
                }
                ?>
                <script>
                    let loggeduser = document.getElementById("myFullName").value; 
                    let userType = document.getElementById("myUserType").value;
                    let userId = document.getElementById("myUserName").value;
                    sessionStorage.setItem("user",loggeduser);
                    sessionStorage.setItem("userType",userType);
                    sessionStorage.setItem("userID",userId);
                  /*  let user = sessionStorage.getItem("user");
                    let userType = sessionStorage.getItem("userType");
                    alert(userType);
                    alert(user); */
                    </script>
                <?php
                
            }
         } 
        else{
            echo "
                <script>
                    alert('Wrong UserName or Password');
                    window.location.replace('../index.php');
                </script>
            ";
                                    
        }
    }
    //echo "<br><a href='../index.php?loggedUser=$fullName&email=$email&userType=$userType&phone=$phone'>Home</a>";
    //header("location:../index.php?loggedUser=$fullName&email=$email&userType=$userType&phone=$phone");
    echo "
    <script>
        window.location.replace('../index.php?loggedUser=$fullName&email=$email&userType=$userType&phone=$phone');
    </script>
";
    
?>

