

<!-- ============================================== HEADER ============================================== -->
<header class="header-style-1"> 
  
  <!-- ============================================== TOP MENU ============================================== -->
  <div class="top-bar animate-dropdown">
    <div class="container">
      <div class="header-top-inner">
        <div class="cnt-account" style="float:left">
          <ul class="list-unstyled">
            <!--<li class="myaccount"><a href="#dashboard"><span>My Account</span></a></li>-->
            <!--<li class="wishlist"><a href="#"><span>Wishlist</span></a></li>-->
            <li class="wishlist"><a href="#"><span>Gift Basket</span></a></li>
           <!-- <li class="header_cart hidden-xs"><a href="#"><span>Shopping Cart</span></a></li> -->
            <li class="check"><a href="src/register.php" onclick="document.getElementById('id01').style.display='block';return false;" style="width:auto;"><span>Register</span></a></li>
            <li class="login" id="loggedin"><a  href="#myModal" class="trigger-btn" data-toggle="modal"><span id = "trigger-btn">Login</span></a></li>
            <li class="logout" id = "loggedout" style="display:none"><span style = "cursor:pointer; color:white;" 
            onclick="offloadPage();"><a href="">Logout</a></span></li>
          </ul>
        </div>

        <!-- Log In Modal HTML -->
      <div id="myModal" class="modal fade">
	        <div class="modal-dialog modal-login">
		          <div class="modal-content">
			            <div class="modal-header">
				              <div class="avatar">
					                <img src="assets/images/akod-logo-no-back.png">
				              </div>				
				              <h4 class="modal-title">Member Login</h4>	
                      <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			              </div>
			              <div class="modal-body">
				                  <form action="src/loginUser.php" method="post">
					                  <div class="form-group">
						                    <input type="text" class="form-control" name="loggedusername" placeholder="Username" required="required">		
					                  </div>
					                  <div class="form-group">
						                    <input type="password" class="form-control" name="loggedpassword" placeholder="Password" required="required">	
					                  </div>        
					                  <div class="form-group">
						                    <button type="submit" name="submit" class="btn btn-primary btn-lg btn-block login-btn">Login</button>
					                  </div> 
                            
				                  </form>
                          
			              </div>
			              <div class="modal-footer">
				                  <a href="#">Forgot Password?</a>
			              </div>
		            </div>
	          </div>
        </div> 
        <!-- /.cnt-account -->
        
        <!--<div class="cnt-block">
          <ul class="list-unstyled list-inline">
            <li class="dropdown dropdown-small"> <a href="#" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown"><span class="value">USD </span><b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#">USD</a></li>
                <li><a href="#">INR</a></li>
                <li><a href="#">GBP</a></li>
              </ul> 
            </li>
            <li class="dropdown dropdown-small lang"> <a href="#" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown"><span class="value">English </span><b class="caret"></b></a>
              <ul class="dropdown-menu">
                <li><a href="#">English</a></li>
                <li><a href="#">French</a></li>
                <li><a href="#">German</a></li>
              </ul>
            </li>
          </ul>
           /.list-unstyled 
        </div> -->
        <!-- /.cnt-cart -->
        <div class="clearfix"></div>
      </div>
      <!-- /.header-top-inner --> 
    </div>
    <!-- /.container --> 
  </div>
  <!-- /.header-top --> 
  <!-- ============================================== TOP MENU : END ============================================== -->
  <div class="main-header">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-3 logo-holder"> 
          <!-- ============================================================= LOGO =============================================================  #2D3192 --> 
          <div class="logo"> <a href="index.php"> <img src="assets/images/akod-logo-no-back.png" alt="logo" 
          style="width:50%; margin:0"> </a> </div>
          <!-- /.logo --> 
          <!-- ============================================================= LOGO : END ============================================================= --> </div>
        <!-- /.logo-holder -->
        
        <div class="col-lg-7 col-md-6 col-sm-8 col-xs-12 top-search-holder"> 
          <!-- /.contact-row --> 
          <!-- ============================================================= SEARCH AREA ============================================================= -->
          <div class="search-area">
            <form>
              <div class="control-group" style="text-align:center;background-color:darkgrey;border-radius:20px;">
               <h1 style="font-family:font-family: 'Lucida Console', 'Courier New', monospace; font-weight:bold;font-size:4em;
               color:#0000cd;">Akod Trading Enterprise</h1>
               <!-- <input class="search-field" placeholder="Search here..." />
                <a class="search-button" href="#" ></a> -->
              </div>
            </form>
          </div>
          <!-- /.search-area  -->
          <!-- ============================================================= SEARCH AREA : END ============================================================= --> </div>
        <!-- /.top-search-holder -->
        
        <div class="col-lg-2 col-md-3 col-sm-4 col-xs-12 animate-dropdown top-cart-row"> 
          <!-- ============================================================= SHOPPING CART DROPDOWN ============================================================= -->
          
          <div class="dropdown dropdown-cart"> 
            <a href="#" class="dropdown-toggle lnk-cart" data-toggle="dropdown" onclick="goToCart();">
            <div class="items-cart-inner">
              <div class="basket">
                <div class="basket-item-count"><span class="count" style="color: #fff !important; font-weight: bold !important;"></span></div>
                <div class="total-price-basket"> 
                    <span class="lbl">Shopping Cart</span><span style="float:left">&#8358;</span> <span style="float:left;margin-left:2px;" id="cartValue" class="value">0</span> 
                  </div>
              </div>
            </div>
            </a>
         <!--   <ul class="dropdown-menu">
              <li>
                <div class="cart-item product-summary">
                  <div class="row">
                    <div class="col-xs-4">
                      <div class="image"> <a href="productdetail"><img src="assets/images/products/p4.jpg" alt=""></a> </div>
                    </div>
                    <div class="col-xs-7">
                      <h3 class="name"><a href="shop">Simple Product</a></h3>
                      <div class="price">$600.00</div>
                    </div>
                    <div class="col-xs-1 action"> <a href="#"><i class="fa fa-trash"></i></a> </div>
                  </div>
                </div> -->
                <!-- /.cart-item -->
            <!--    <div class="clearfix"></div>
                <hr>
                <div class="clearfix cart-total">
                  <div class="pull-right"> <span class="text">Sub Total :</span><span class='price'>&#8358; 600.00</span> </div>
                  <div class="clearfix"></div>
                  <a href="checkout" class="btn btn-upper btn-primary btn-block m-t-20">Checkout</a> </div> -->
                <!-- /.cart-total--> 
                
         <!--     </li>
            </ul> -->
            <!-- /.dropdown-menu--> 
          </div>
          <!-- /.dropdown-cart --> 
          
          <!-- ============================================================= SHOPPING CART DROPDOWN : END============================================================= --> </div>
        <!-- /.top-cart-row --> 
      </div>
      <!-- /.row --> 

      <div class="row">
        <div class="col">
          <div id="logged-in-user" style="display:block; color: white; text-align:center;">
          <?php
          if(isset($_GET['loggedUser'])){
              $loggedUser = $_GET["loggedUser"];
              echo "Logged in User: ". $loggedUser;
          }
        ?>
        </div>
        </div>
      </div>
      
    </div>
    <!-- /.container --> 
    
  </div>
  <!-- /.main-header --> 
  
  <!-- ============================================== NAVBAR ============================================== -->
  <div class="header-nav animate-dropdown" style="">
    <div class="container">
      <div class="yamm navbar navbar-default" role="navigation">
        <div class="navbar-header">
       <button data-target="#mc-horizontal-menu-collapse" data-toggle="collapse" class="navbar-toggle collapsed" type="button"> 
       <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
        </div>
        <div id="main-menu" class="nav-bg-class" style = "margin:auto">
          <div class="navbar-collapse collapse" id="mc-horizontal-menu-collapse">
            <div class="nav-outer">
              <ul class="nav navbar-nav">
                <li class="active dropdown"> <a href="index.php">Home</a> </li>
                <li id="manage-users" class="dropdown hidden-sm" style=""><a href="manageUsers.php">Manage Users</a></li>
                <li id="manage-products" class="dropdown hidden-sm" style=""><a href="manageProducts.php">Manage Products</a></li>
                <li class="dropdown hidden-sm"> <a href="contact.php">Contact Us </a> </li>
                <li class="dropdown"> <a href="productlist.php" class="dropdown-toggle" data-hover="dropdown" data-toggle="dropdown">Market Place</a>
                  <ul class="dropdown-menu pages">
                    <li>
                      <div class="yamm-content">
                        <div class="row">
                          <div class="col-xs-12 col-menu">
                            <ul class="links">
                              <li><a href="productlist.php?productCategoryId1=AkodCat01">Grains & Cereals</a></li>
                              <li><a href="productlist.php?productCategoryId1=AkodCat02">Vegetable Oil</a></li>
                              <li><a href="productlist.php?productCategoryId1=AkodCat03">Seasonings &<br> Flavours</a></li>
                              <li><a href="productlist.php?productCategoryId1=AkodCat04">Pastas & Noddles</a></li>
                              <li><a href="productlist.php?productCategoryId1=AkodCat05">Tomatoes Pastes<br> & Mixes</a></li>
                              <li><a href="productlist.php?productCategoryId1=AkodCat06">Energy Food Drinks</a></li>
                              <li><a href="productlist.php?productCategoryId1=AkodCat07">Flour Meals</a></li>
                              <li><a href="productlist.php?productCategoryId1=AkodCat08">Pasteries & <br>Oven Products</a></li>
                              <li><a href="productlist.php?productCategoryId1=AkodCat10">Sugars & Mayonnaise</a></li>
                              <li><a href="productlist.php?productCategoryId1=AkodCat09">Frozen Food</a></li>
                              <li><a href="productlist.php?productCategoryId1=AkodCat11">Live Poultry/Goats/Cows</a></li>
                            </ul>
                          </div>
                        </div>
                      </div>
                    </li>
					
                  </ul>
                </li>
              </ul>
              <!-- /.navbar-nav -->
              <div class="clearfix"></div>
            </div>
            <!-- /.nav-outer --> 
          </div>
          <!-- /.navbar-collapse --> 
          
        </div>
        <!-- /.nav-bg-class --> 
      </div>
      <!-- /.navbar-default --> 
    </div>
    <!-- /.container-class --> 
    
  </div>
  <!-- /.header-nav --> 
  <!-- ============================================== NAVBAR : END ============================================== --> 
  
</header>

<!-- ============================================== HEADER : END ============================================== -->