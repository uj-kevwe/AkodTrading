<body>
    <input type = "text" id="loggedUser" value ="">
    <?php
        include("databaseconnection.php") ;
        $loggedUser = $_GET["loggedUser"];
        $sql = "update userstbl set Status = 'Inactive' where UserID = '$loggedUser'";
        $result=$conn->query($sql);
        echo $sql;
        if($result){
            //RETURN TO HOME PAGE
            echo "<script>sessionStorage.clear();</script>";
            echo "<script>window.location.replace('../index.php');</script>";
        }
        else{
            echo $conn->error;
        }
    ?>
    <script>
        user = sessionStorage.getItem("user");
        //alert("Logged On User: " + user);
        if(user != null){
            document.getElementById("loggedUser").value = user;
        }
         
    </script>
</body>