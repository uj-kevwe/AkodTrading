<?php

$sql1 = "select * from producttbl";
// echo $sql1;
$result1 = $conn->query($sql1);
if($result1->num_rows>0){
    while($rows1=$result1->fetch_assoc()){
        $productCatId = $rows1["productCatId"];
        $productId = $rows1["productId"];
        $productName =$rows1["ProductName"];
        $brandName = $rows1["BrandName"];
        $productDescription = $rows1["ProductDescription"];
        $productNetWeight = $rows1["ProductNetWeight"];
        $wholeSalePrice = $rows1["WholeSalePrice"];
        $retailSalePrice = $rows1["RetailSalePrice"];
        $stock_unit = $rows1["StockUnit"];
        $stock_level = $rows1["StockLevel"];
        echo "<input class='$productCatId' type = 'hidden' value = '$productName' brand='$brandName'
        descr = '$productDescription' netweight = '$productNetWeight' whole = '$wholeSalePrice' retail = '$retailSalePrice'
        stockLevel = '$stock_level' stockUnit = '$stock_unit'>";
    }
}
else{ echo $conn->error;}                    
?>
<form>
<div style="width:90%;margin-left:5%; border-width:2px; border-color:blue; background-color: lightgrey; padding:5px;">
    <select id="categories" onchange="selectCategory();">
        <option>Select A Category</option>
        <?php
            $sql = "select * from categorytbl";
            $result = $conn->query($sql);
            if($result->num_rows>0){
                while($rows=$result->fetch_assoc()){
                    $id = $rows["ProductCatId"];
                    echo "<option id = '$id'>".$rows['CategoryName']."</option>";
                }
            }
        ?>
    </select>
    
</div>
<div style="width:90%;margin:0 5% 1% 5%;height:400px; overflow-y:scroll">
    <table id = "viewProduct">
        <tr>
<!--                                <th style ="width:5%">S/No</th>  -->
            <th style ="width:15%">Brand Name</th>
            <th style ="width:20%">Product Name</th>
            <th style ="width:25%">Product Description</th>
            <th style ="width:10%">Net Weight</th>
            <th style ="width:10%">Whole Sale Price</th>
            <th style ="width:10%">Retail Price</th>
            <th style = "width:10%">Stock Level</th>
          <!--  <th>Stock Level</th> -->
        </tr>
        <label id = "totalProducts"></label>
    </table>
</div>
</form>