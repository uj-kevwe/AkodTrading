<div style="width:90%;margin-left:5%; border-width:2px; border-color:blue; background-color: lightgrey; padding:5px;">
    <select id = "products" >
        <option>Select a product</option>
        <?php
            $sql_products = "select * from producttbl";
            $result_products = $conn->query($sql_products);
            if($result_products->num_rows>0){
                while($rows_products = $result_products->fetch_assoc()){
                    echo "<option>$rows_products['ProductName']</option>";
            }
        }
    ?>
    </select>
</div>