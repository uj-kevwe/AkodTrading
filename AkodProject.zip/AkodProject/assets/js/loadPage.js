function loadPage(){
  let status = sessionStorage.getItem("user");
  let userType=sessionStorage.getItem("userType");
  //alert(status);
  if (status==null){
    //alert(status);
    document.getElementById("loggedin").style.display = "inline";
    document.getElementById("loggedout").style.display = "none";
    document.getElementById("logged-in-user").innerHTML = "";
  }
  else{
    //alert(status);
    document.getElementById("loggedin").style.display = "none";
    document.getElementById("loggedout").style.display = "inline";
    //document.getElementById("logged-in-user").style.display = "block";
  }
  if(userType=="Developer"){
      //alert(sessionStorage.getItem("userType"));
      document.getElementById("manage-users").style.display="inline";
      document.getElementById("manage-products").style.display="inline";
    }
    else{
      //alert(sessionStorage.getItem("userType"));
      document.getElementById("manage-users").style.display="none";
      document.getElementById("manage-products").style.display="none";
    }
}
function offloadPage(){
  user = sessionStorage.getItem("user");
  userId = sessionStorage.getItem("userID");
  location.replace("src/logout.php?loggedUser="+userId);
  loadPage();
}
function goToMarketPlace(){
  let url = "productlist.php?";
  let emptyUrl = true;

  let cat01 = document.getElementById("AkodCat01");
  let cat02 = document.getElementById("AkodCat02");
  let cat03 = document.getElementById("AkodCat03");
  let cat04 = document.getElementById("AkodCat04");
  let cat05 = document.getElementById("AkodCat05");
  let cat06 = document.getElementById("AkodCat06");
  let cat07 = document.getElementById("AkodCat07");
  let cat08 = document.getElementById("AkodCat08");
  let cat09 = document.getElementById("AkodCat09");
  let cat10 = document.getElementById("AkodCat10");
  let cat11 = document.getElementById("AkodCat11");
  let all = document.getElementById("All");

  if(cat01.checked==true){
    if(emptyUrl== true){url = url + "productCategoryId1=AkodCat01";emptyUrl = false;} else{url = url + "&productCategoryId1=AkodCat01";}
  }
  if(cat02.checked==true){
    if(emptyUrl== true){url = url + "productCategoryId2=AkodCat02";emptyUrl = false;} else{url = url + "&productCategoryId2=AkodCat02";}
  }
  if(cat03.checked==true){
    if(emptyUrl== true){url = url + "productCategoryId3=AkodCat03";emptyUrl = false;} else{url = url + "&productCategoryId3=AkodCat03";}
  }
  if(cat04.checked==true){
    if(emptyUrl== true){url = url + "productCategoryId4=AkodCat04";emptyUrl = false;} else{url = url + "&productCategoryId4=AkodCat04";}
  }
  if(cat05.checked==true){
    if(emptyUrl== true){url = url + "productCategoryId5=AkodCat05";emptyUrl = false;} else{url = url + "&productCategoryId5=AkodCat05";}
  }
  if(cat06.checked==true){
    if(emptyUrl== true){url = url + "productCategoryId6=AkodCat06";emptyUrl = false;} else{url = url + "&productCategoryId6=AkodCat06";}
  }
  if(cat07.checked==true){
    if(emptyUrl== true){url = url + "productCategoryId7=AkodCat07";emptyUrl = false;} else{url = url + "&productCategoryId7=AkodCat07";}
  }
  if(cat08.checked==true){
    if(emptyUrl== true){url = url + "productCategoryId8=AkodCat08";emptyUrl = false;} else{url = url + "&productCategoryId8=AkodCat08";}
  }
  if(cat09.checked==true){
    if(emptyUrl== true){url = url + "productCategoryId9=AkodCat09";emptyUrl = false;} else{url = url + "&productCategoryId9=AkodCat09";}
  }
  if(cat10.checked==true){
    if(emptyUrl== true){url = url + "productCategoryId10=AkodCat10";emptyUrl = false;} else{url = url + "&productCategoryId10=AkodCat10";}
  }
  if(cat11.checked==true){
    if(emptyUrl== true){url = url + "productCategoryId11=AkodCat11";emptyUrl = false;} else{url = url + "&productCategoryId11=AkodCat11";}
  }

  window.open(url);
}

function checkAll(){
  let cat01 = document.getElementById("AkodCat01");
  let cat02 = document.getElementById("AkodCat02");
  let cat03 = document.getElementById("AkodCat03");
  let cat04 = document.getElementById("AkodCat04");
  let cat05 = document.getElementById("AkodCat05");
  let cat06 = document.getElementById("AkodCat06");
  let cat07 = document.getElementById("AkodCat07");
  let cat08 = document.getElementById("AkodCat08");
  let cat09 = document.getElementById("AkodCat09");
  let cat10 = document.getElementById("AkodCat10");
  let cat11 = document.getElementById("AkodCat11");
  let all = document.getElementById("All");

  if(all.checked==true){
    cat01.checked = true;cat02.checked = true;cat03.checked = true;cat04.checked = true;
    cat05.checked = true;cat06.checked = true;cat07.checked = true;cat08.checked = true;
    cat09.checked = true;cat10.checked = true;cat11.checked = true;
  }
  else{
    cat01.checked = false;cat02.checked = false;cat03.checked = false;cat04.checked = false;
    cat05.checked = false;cat06.checked = false;cat07.checked = false;cat08.checked = false;
    cat09.checked = false;cat10.checked = false;cat11.checked = false;
  }
}
function getUserDetails(){
  
 
} 

function logout(){
  document.getElementById("username").value = "";
  document.getElementById("phone").value = "";
  document.getElementById("email").value = "";
  document.getElementById("userType").value = "";
  document.getElementById("fullName").value = "";

  document.getElementById("login").style.display = "block";
  document.getElementById("logout").style.display = "none";
}

function goToCart(){
  window.open("../../cartPge.php");
}

function loadProductPage(){
  /*  let categoryName = document.getElementById("categoryName").value;
    alert(categoryName);*/
    alert('AKOD TRADING ENTERPRISES PRODUCT LIST BY CATEGORY '/* + categoryName*/);
}
 function showToolTip(x){
    let tooltip = "tooltip" + x;
    document.getElementById(tooltip).style.display ="block";
}
function closeToolTip(x){
    let tooltip = "tooltip" + x;
    document.getElementById(tooltip).style.display ="none";
}
function showProductDetails(x){
    
    let pimage = document.getElementById(x).getAttribute("image")+".jpg";
    let pWholeSale = document.getElementById(x).getAttribute("wholeSalePrice");
    let pRetailSale = document.getElementById(x).getAttribute("retailSalePrice");
    /*document.getElementById("prodImage").src = "assets/images/productlist/"+ pimage;*/
    document.getElementById("wprice").innerHTML = pWholeSale;
    document.getElementById("rprice").innerHTML = pRetailSale;
    document.getElementById("descrDetails").style.display = "block";
}
  function addToCart(x){
    let productName = document.getElementById(x).getAttribute("productName");
    let productDescr = document.getElementById(x).getAttribute("productDescr");
    let brandName = document.getElementById(x).getAttribute("brandName");
    let wholeSalePrice = document.getElementById(x).getAttribute("wholeSalePrice");
    let retailSalePrice = document.getElementById(x).getAttribute("retailSalePrice");
    let form = document.getElementById("cartItems");
    let itemName = "ItemName" + x; 
    let itemBrand = "ItemBrand" + x;
    let itemWholeSalePrice = "ItemWholeSalePrice" + x;
    let itemRetailSalePrice = "ItemRetailSalePrice" + x;
    let totalAmount = document.getElementById("grandTotal").value;
    
    document.getElementById(x).checked = true;

    if(document.getElementById(x).checked==true){ 
        let r = prompt("Details of Product You are Adding To Cart\n"+
        "\nProduct Name: " + productName + 
        "\nBrand Name: " + brandName +
        "\nDescription: " + productDescr +
        "\n\n[1] Confirm " + brandName + " " + productName + " and Continue Shopping" +
        "\n[2] Confirm " + brandName + " " + productName + " and Proceed to Purchase Invoice" +
        "\n[3] Cancle " + brandName + " " + productName + " and Continue Shopping");
        if(r=="1"){
            let table = document.getElementById("orderTable");
            let tableLength = table.rows.length;
            let dtr = table.insertRow(tableLength);

            let sNo = document.createElement("td");
            sNo.innerHTML = tableLength-1;
            dtr.appendChild(sNo);

            let dProductName = document.createElement("td"); 
            dProductName.innerHTML = productName;
            dtr.appendChild(dProductName);

            let dBrandName = document.createElement("td"); 
            dBrandName.innerHTML = brandName;
            dtr.appendChild(dBrandName);

            //confirm if wholesale purchase or retail purchase
            let purchaseType = prompt("Are you purchaseing " + brandName + " " + productName + " on Wholesale or Retail" +
            "\n\n[1] WholeSale Purchases" +
            "\n[2] Retail Purchase");
            if (purchaseType == "1"){
                let wholeSaleQty = prompt("Input WholeSale Quantity");
                let wholeSaleAmt = parseInt(wholeSaleQty) * parseInt(wholeSalePrice);
                totalAmount = parseInt(totalAmount) + wholeSaleAmt;
                document.getElementById("cartValue").innerHTML = totalAmount;
                document.getElementById("grandTotal").value = totalAmount.toString();

                let purType = document.createElement("td");
                purType.innerHTML = "WholeSale Purchase";
                dtr.appendChild(purType); 

                let dWholeSale = document.createElement("td");
                dWholeSale.innerHTML =  wholeSalePrice
                dtr.appendChild(dWholeSale);

                let dQty = document.createElement("td");
                dQty.innerHTML = wholeSaleQty;
                dtr.appendChild(dQty);

                let dAmt = document.createElement("td");
                dAmt.innerHTML = wholeSaleAmt;
                dtr.appendChild(dAmt);

                table.appendChild(dtr);
            }
            else if (purchaseType == "2"){
                let retailSaleQty = prompt("Input Retail Quantity");
                let retailAmt = parseInt(retailSaleQty) * parseInt(retailSalePrice);
                totalAmount = parseInt(totalAmount) + retailAmt;
                document.getElementById("cartValue").innerHTML = totalAmount;
                document.getElementById("grandTotal").value = totalAmount.toString();

                let purType = document.createElement("td");
                purType.innerHTML = "Retail Purchase";
                dtr.appendChild(purType); 

                let dRetailSale = document.createElement("td");
                dRetailSale.innerHTML = retailSalePrice 
                dtr.appendChild(dRetailSale);

                let dQty = document.createElement("td");
                dQty.innerHTML = retailSaleQty;
                dtr.appendChild(dQty);

                let dAmt = document.createElement("td");
                dAmt.innerHTML = retailAmt;
                dtr.appendChild(dAmt);

                table.appendChild(dtr);
            }
            else{
                alert("You must chose either 1 or 2");
            }   
        }

        else if(r=="2"){
            //processSales();
            let table = document.getElementById("orderTable");
            let tableLength = table.rows.length;
            let dtr = table.insertRow(tableLength);

            
            let sNo = document.createElement("td");
            sNo.innerHTML = tableLength-1;
            dtr.appendChild(sNo);

            let dProductName = document.createElement("td"); 
            dProductName.innerHTML = productName;
            dtr.appendChild(dProductName);

            let dBrandName = document.createElement("td"); 
            dBrandName.innerHTML = brandName;
            dtr.appendChild(dBrandName);

            //confirm if wholesale purchase or retail purchase
            let purchaseType = prompt("Are you purchaseing " + brandName + " " + productName + " on Wholesale or Retail" +
            "\n\n[1] WholeSale Purchases" +
            "\n[2] Retail Purchase");
            if (purchaseType == "1"){
                let wholeSaleQty = prompt("Input WholeSale Quantity");
                let wholeSaleAmt = parseInt(wholeSaleQty) * parseInt(wholeSalePrice);
                totalAmount = parseInt(totalAmount) + wholeSaleAmt;
                document.getElementById("cartValue").innerHTML = totalAmount;
                document.getElementById("grandTotal").value = totalAmount.toString();

                let purType = document.createElement("td");
                purType.innerHTML = "WholeSale Purchase";
                dtr.appendChild(purType); 

                let dWholeSale = document.createElement("td");
                dWholeSale.innerHTML =  wholeSalePrice
                dtr.appendChild(dWholeSale);

                let dQty = document.createElement("td");
                dQty.innerHTML = wholeSaleQty;
                dtr.appendChild(dQty); 

                let dAmt = document.createElement("td");
                dAmt.innerHTML = wholeSaleAmt;
                dtr.appendChild(dAmt); 

                table.appendChild(dtr);

             
                let totalRow = table.insertRow(); alert(totalRow);

                let ltotal = document.createElement("td");
                ltotal.setAttribute("colspan","5");
                ltotal.innerHTML = "Total";
                totalRow.appendChild(ltotal);

                let dtotal = document.createElement("td");
                dtotal.setAttribute("colspan","2");
                dtotal.innerHTML = totalAmount;
                totalRow.appendChild(dtotal);

                table.append(totalRow);
                form.appendChild(table);
/*
                let btn = document.createElement("input");
                btn.setAttribute("type", "button");
                btn.setAttribute("name", "submitBtn");
                btn.setAttribute("id","submitBtn");
                btn.setAttribute("value","Proceed To Cart");

                form.appendChild(btn); */
            }
            else if (purchaseType == "2"){
                let retailSaleQty = prompt("Input Retail Quantity");
                let retailAmt = parseInt(retailSaleQty) * parseInt(retailSalePrice);
                totalAmount = parseInt(totalAmount) + retailAmt;
                document.getElementById("cartValue").innerHTML = totalAmount;
                document.getElementById("grandTotal").value = totalAmount.toString();

                let purType = document.createElement("td");
                purType.innerHTML = "Retail Purchase";
                dtr.appendChild(purType);  

                let dRetailSale = document.createElement("td");
                dRetailSale.innerHTML = retailSalePrice 
                dtr.appendChild(dRetailSale);

                let dQty = document.createElement("td");
                dQty.innerHTML = retailSaleQty;
                dtr.appendChild(dQty);

                let dAmt = document.createElement("td");
                dAmt.innerHTML = retailAmt;
                dtr.appendChild(dAmt); 


                table.appendChild(dtr);

                let totalRow = table.insertRow(); alert(totalRow);

                let ltotal = document.createElement("td");
                ltotal.setAttribute("colspan","5");
                ltotal.innerHTML = "Total";
                totalRow.appendChild(ltotal);

                let dtotal = document.createElement("td");
                dtotal.setAttribute("colspan","2");
                dtotal.innerHTML = totalAmount;
                totalRow.appendChild(dtotal);

                table.append(totalRow);
                form.appendChild(table);

/*                        let btn = document.createElement("input");
                btn.setAttribute("type", "button");
                btn.setAttribute("name", "submitBtn");
                btn.setAttribute("id","submitBtn");
                btn.setAttribute("value","Proceed To Cart");

                form.appendChild(btn);*/
            }
            else{
                alert("You must chose either 1 or 2");
            }
            document.getElementById("cartItems").style.display = "block";
        }
        else if(r=="3"){
            document.getElementById(x).checked = false;
        }
        else{
            alert("Please pick a choice between 1 to 3")
            document.getElementById(x).checked = false;
        }
    } 
   else{
        let r = confirm("Details of Product You are Removing From Cart\n" +
        "\nProduct Name: " + productName +
        "\nBrand Name: " + brandName +
        "\nDescription: " + productDescr +
        "\n\nClick ok to confirm this selection") ;
        if(r==true){
            document.getElementById(x).checked = false;
        }
        else{
            document.getElementById(x).checked = true;
        }
    } 
    
} 
 function goToCart(){
    loggedUser = sessionStorage.getItem("userID");
     location.replace("checkout.php?loggedUser="+loggedUser);
 }

