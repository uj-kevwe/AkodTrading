<?php
date_default_timezone_set ("Africa/Lagos");
error_reporting(0);
session_start();


?>
