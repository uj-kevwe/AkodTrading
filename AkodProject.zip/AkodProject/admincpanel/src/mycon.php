<?php

$database_getImage1 = "akodent_db";
$hostname_getImage1 = "localhost";
$username_getImage1 = "root";
$password_getImage1 = "";

$dbconn = new mysqli($hostname_getImage1, $username_getImage1, $password_getImage1,$database_getImage1);
 
// Check connection
if($dbconn === false){
    die("ERROR: Could not connect. " . $mysqli->connect_error);
}


?>