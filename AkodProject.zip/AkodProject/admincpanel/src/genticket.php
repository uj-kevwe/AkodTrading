<?php

include('session.php');

$date = time();
$month = date('n', $date);
$day = date('j', $date);
$hour = date('g', $date);
$minute = date('i', $date);
$second = date('s', $date);
$year = date('Y', $date);

$s = substr(session_id(), 0, 3);
$dpersonemail = substr($_SESSION['user_name'], 0, 5);

$sessionid = $month . $year . $hour . $minute . $second .$s  . $dpersonemail;
$orderno  = $sessionid;

$_SESSION['ordernumber'] = $orderno;


?>  

