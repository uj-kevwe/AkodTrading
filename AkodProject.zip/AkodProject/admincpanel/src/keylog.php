<?php
include('session.php');
require("myconnect.php");


//record activity
$query_imageRandomPROu = "SELECT * FROM staff_tbl WHERE st_email = '".$_SESSION['user_name']."'";
$imageRandomPROu = mysqli_query($db,$query_imageRandomPROu) or die(mysqli_error());
$row_imageRandomPROu  = mysqli_fetch_assoc($imageRandomPROu);
$totalRows_imageRandomPROu  = mysqli_num_rows($imageRandomPROu);

$thenames = $row_imageRandomPROu['st_name'];


mysqli_query($db,"INSERT INTO auditlog(fname,dfulldate,daction) VALUES ('".$thenames."', NOW(),'".$daction."')");


//record end






?>
