<?php 
include('session.php');
include('myconnect.php');
include('is_function.php');

$timmingss = date('Y-m-d h:i:s');

if(isset($_POST['action'])){
		
        $emailuser = mysqli_real_escape_string($db,$_POST['emailuser']);
        $passworduser = mysqli_real_escape_string($db,$_POST['passworduser']);
		
        $strSQL = mysqli_query($db,"SELECT * FROM login_tbl 
		WHERE useremail = '".$emailuser."' 
		AND userpassword = '".md5($passworduser)."' 
		AND status = '1' ");
		
        $Results = mysqli_fetch_assoc($strSQL);
		
        if($Results){			
			$_SESSION['user_name'] = $Results['useremail'];
			$_SESSION['sbranch'] = $Results['userlocation'];				
			
			mysqli_query($db,"INSERT INTO clockinclockout(clockin,clockuser) VALUES ('".$timmingss."','".$_SESSION['user_name']."' )");
			
            //$message = $Results['fname']." Login Sucessfully!!";
			echo '<script type="text/javascript">
			alert("You have Sucessfully login into your accouunt!!");
			window.location.href = "../index.php";</script>';
			
        }else{
           //$message = "Invalid email or password!!";
			echo '<script type="text/javascript">
			alert("You have provided invalid email or password, try again!!");
			window.location.href = "../login.php";</script>';
        }        
    }
	
	
	if(isset($_POST['RECOVER'])){
	
       	$emailuser = es(s($db,$_POST['emailuser']));
		$strSQLii = "SELECT * FROM login_tbl WHERE useremail = '".$emailuser."'";
		$resii = mysqli_query($db, $strSQLii);
		$countii = mysqli_num_rows($resii);
		if($countii == 1){
			$rii = mysqli_fetch_assoc($resii);
			$password = $rii['off_pwd'];
			$to = $rii['email'];
			$subject = "Your Recovered Password";
	 
			$message .= "Your username/email " . $to ."\n";
			$message .= "Please use this password to login " . $password ."\n";
			$headers = "From : EMS EKESONS Transport (Admin Unit)";
			if(mail($to, $subject, $message, $headers)){
				echo "<script>alert('Your Password has been sent to your email address');</script>";
			}else{
				echo "<script>alert('Failed to Recover your password, try again');</script>";
			}
	 
		}else{
			echo "<script>alert('Details provided does not exist in our data engine');</script>";
		}
	}
	


?>