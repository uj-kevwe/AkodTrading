<!DOCTYPE html>
<html lang="en">

<head>
<!-- Meta -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<meta name="keywords" content="MediaCenter, Template, eCommerce">
<meta name="robots" content="all">
<title>AKOD TRADING ENTERPRISE | Cereals | Mayonnaise | Grains | Flour Meals | Energy Food Drinks | Vegetable Oil | Flavours | Noodles | Sugar </title>

<!-- Bootstrap Core CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">

<!-- Customizable CSS -->
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/css/blue.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.transitions.css">
<link rel="stylesheet" href="assets/css/animate.min.css">
<link rel="stylesheet" href="assets/css/rateit.css">
<link rel="stylesheet" href="assets/css/bootstrap-select.min.css">
<link rel="stylesheet" href="assets/css/login.css">
<!--<link rel="stylesheet" href="assets/css/register.css"> -->

<!-- Icons/Glyphs -->
<link rel="stylesheet" href="assets/css/font-awesome.css">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Barlow:200,300,300i,400,400i,500,500i,600,700,800" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
<style>
    hr{
        border-color:blue;
        border-width:2px;
    }
    #products-menu {
        margin: 15px 10px 5px 10px;
        padding: 20px; 
        height: 450px; 
        background-color:#d9ff66
    }
    #products-menu li{
        margin-left:20px; margin-top:5px;
        font-weight:bold;
    }
    #subProducts li{
        font-weight: normal;
    }
    #subProducts hr{
        border-width:1px;
    }
    #viewByCategory, #viewByProductName, #managePrices, #restockProducts {
        height: 450px;
        margin: 15px 10px 5px 10px;
        padding: 10px; 
        background-color:white;
        display:none;
    }
    #adminHome{
        height: 450px;
        margin: 15px 10px 5px 10px;
        padding: 20px; 
        background-color:blue;
        color:white;
        display:block;
    }

</style>
</head>

<body class="cnt-home" onload="loadPage();">
<?php 
    include("src/header.php");
    include("src/databaseconnection.php");
?>
<div class = "container-fluid" style="height: 500px;">
    <div class = "row" style=" background-color:black">
        <div class="col-xs-12 col-sm-12 col-md-3" style="background-color: lightgrey; height: 500px;">
            <div id="products-menu" style="">
                <h4>Dashboard</h4>
                <ul>
                    <hr>
                    <li><a href="" onclick="showDiv('adminHome'); return false;">Home</a></li><hr>
                    <li>
                        <a href="" onclick="toggleMenu(); return false;">View Products</a>
                        <ul id="subProducts" style="display:none; margin-left:20px;">
                            <li><a href="" onclick="showDiv('viewByCategory');return false;">By Categories<a></li><hr>
                            <li><a href="" onclick="showDiv('viewByProductName');return false;">Product Name</a></li>
                        </ul>
                    </li><hr>
                    <li>
                        <a href="" onclick="showDiv('managePrices');return false;">Manage Prices</a>
                    </li><hr>
                    <li>
                        <a href="" onclick="showDiv('restockProducts');return false;">Manage Products</a>
                    </li><hr>
                </ul>
            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-9">
            <div id="adminHome"></div>
            <div id = "viewByCategory">
                <?php include("src/viewByCategories.php");?>
            </div>
            <div id = "viewByProductName">
                <?php
                     $sql = "select * from producttbl";
                     $result = $conn->query($sql);
                     if($result->num_rows>0){
                         $i=0;
                         while($row=$result->fetch_assoc()){
                            ++$i;
                            $id = "product".$i;
                             $productId = $row["productId"];
                             $productName = $row["ProductName"];
                             $productBrand = $row["BrandName"];
                             $wholeSale = $row["WholeSalePrice"];
                             $retailSale = $row["RetailSalePrice"];
                             $netweight = $row["ProductNetWeight"];
                             $stockValue = $row["StockLevel"].$row["StockUnit"];
                             echo "<input type='hidden' id='$id'  value = '$productId' productName = '$productName' productBrand = '$productBrand'
                              wholeSale = '$wholeSale' retailSale = '$retailSale' netweight = '$netweight' stockValue = '$stockValue'>";

                         }
                     }

                    $sql2 = "select * from producttbl";
                    $result2 = $conn->query($sql2);
                ?>
                <div id="selectRow" style = "background-color:lightgrey;padding:20px;">
                    <select id="selectedProduct" onchange="showProductDetails();">
                        <option>Select a Product</option>
                        <?php 
                            if($result2->num_rows>0){
                                $sno = 0;
                                while($rows2=$result2->fetch_assoc()){
                                    echo "<option>".++$sno.'->'. $rows2['BrandName'].': '.$rows2['ProductName'].' '.$rows2['ProductDescription']."</option>";
                                }
                            }
                            else{
                                echo $conn->error;
                            }
                        ?>
                    </select>
                </div>
                <div id="prodDescrRow" style="margin:20px; display:block">
                    <div class="container">
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-5" id="prodImg">
                                <img id="productImage" src="" style="width:60%;">
                            </div>
                            <div class="col-xs-12 col-sm-12 col-md-7" id="prodDescr">
                                <form>
                                    <div>
                                        <label id=lblProductName style="width:40%">Product Name</label>
                                        <input id="txtProductName" type = "text" value = "" disabled style="width:60%">
                                    </div>
                                    <div>
                                        <label id=lblProductBrand style="width:40%">Product Brand</label>
                                        <input id="txtProductBrand" type = "text" value = "" disabled style="width:60%">
                                    </div>
                                    <div>
                                        <label id=lblWholeSale style="width:40%">Whole Sale Price</label>
                                        <input id="txtWholeSale" type = "text" value = "" disabled style="width:60%">
                                    </div>
                                    <div>
                                        <label id=lblRetailSale style="width:40%">Retail Sale Price</label>
                                        <input id="txtRetailSale" type = "text" value = "" disabled style="width:60%">
                                    </div>
                                    <div>
                                        <label id=lblStockValue style="width:40%">Product Stock Level</label>
                                        <input id="txtStockValue" type = "text" value = "" disabled style="width:60%">
                                    </div>
                                    <div>
                                        <label id=lblProuctNetWeight style="width:40%">Product Net Weight</label>
                                        <input id="txtProductNetWeight" type = "text" value = "" disabled style="width:60%">
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id = "managePrices">
                <?php
                    $sql = "select * from producttbl";
                    $result = $conn->query($sql);
                    if($result->num_rows>0){
                        $i=0;
                        while($row = $result->fetch_assoc()){
                            $id = "price".++$i;
                             $productId = $row["productId"];
                             $productName = $row["ProductName"];
                             $productBrand = $row["BrandName"];
                             $wholeSale = $row["WholeSalePrice"];
                             $retailSale = $row["RetailSalePrice"];
                             $netweight = $row["ProductNetWeight"];
                             $stockValue = $row["StockLevel"].$row["StockUnit"];
                             echo "<input type='hidden' id='$id'  value = '$productId' price_productName = '$productName' price_productBrand = '$productBrand'
                              price_wholeSale = '$wholeSale' price_retailSale = '$retailSale' price_netweight = '$netweight' price_stockValue = '$stockValue'>";
                        }
                    }
                ?>
                <div id = "selectManagePrice" style="background-color:lightgrey; padding:10px">
                    <select id="productPrices" onchange = "managePrices();">
                        <option>Select A Product</option>
                        <?php
                            $sql = "select * from producttbl";
                            $result = $conn->query($sql);
                            if($result->num_rows>0){
                                while($row = $result->fetch_assoc()){
                                    echo "<option>".$row["BrandName"]." ".$row["ProductName"]." ".$row["ProductDescription"]."</option>";
                                }
                            }
                        ?>
                    </select>
                </div>
                <div id = "managePrice" style="margin-top:15%">
                    <form action="<?php echo $_SERVER['PHP_SELF'];?>">
                        <div id = "wholesaleprice" style="float:left; width:40%; margin-left:5%; margin-right:5%">
                            <div id="oldwholesale">
                                <label style="width:40%;float:left">Old Whole Sale Price</label>
                                <input id="txtoldwholesaleprice" type="text" value = "" disabled style="width:60%;float:right;">
                            </div>
                            <div id="newwholesale">
                                <label style="width:40%;float:left">New Whole Sale Price</label>
                                <input id="txtnewwholesaleprice" name="txtnewwholesaleprice" type="text" value = "" style="width:60%;float:right;">
                            </div>
                        </div>
                        <div id = "retailsaleprice" style="float:right;width:40%; margin-right:5%; margin-left:5%">
                            <div id="oldretailsale">
                                <label style="width:40%;float:left">Old Retail Sale Price</label>
                                <input id="txtoldretailsaleprice" type="text" value = "" disabled style="width:60%;float:right;">
                            </div>
                            <div id="newretailsale">
                                <label style="width:40%;float:left">New Retail Sale Price</label>
                                <input id="txtnewretailsaleprice" name="txtnewretailsaleprice" type="text" value = "" style="width:60%;float:right;">
                            </div>
                        </div>
                        <div style="text-align:center;margin-top:50px">
                            <input type = "submit" id="submitBtn" name = "submitBtn" value="Update Price">
                        </div>
                        <input type="hidden" name = "selectedProductId" id="selectedProductId" value="">
                    </form>
                    <?php
                        //echo print_r($_POST);
                        if(isset($_GET["txtnewwholesaleprice"])){$newWholeSale = $_GET["txtnewwholesaleprice"];}
                        if(isset($_GET["txtnewretailsaleprice"])){$newRetailSale = $_GET["txtnewretailsaleprice"];}
                        if(isset($_GET["selectedProductId"])){
                            $productId = $_GET["selectedProductId"];

                            $sql1 = "update producttbl set WholeSalePrice ='$newWholeSale' where productId = '$productId'";
                            $result1 = $conn->query($sql1);

                            $sql2 = "update producttbl set RetailSalePrice ='$newRetailSale' where productId = '$productId'";
                            $result2 = $conn->query($sql2);
                        }
                    ?>
                </div>
            </div>
            <div id = "restockProducts"></div>
        </div>
    </div>
</div>
<?php include("src/footer.php"); ?>
<script>
    function toggleMenu(){
        if(document.getElementById("subProducts").style.display=="none"){
            document.getElementById("subProducts").style.display="block";
        }
        else{
            document.getElementById("subProducts").style.display="none";
        }
    }

    function showDiv(id){
        if(id=="viewByCategory"){
            table = document.getElementById("viewProduct"); 
            while(table.rows.length>1){
                //alert("deleting rows");
                document.getElementById("viewProduct").deleteRow(1);
            }
            document.getElementById("adminHome").style.display = "none";
            document.getElementById("viewByCategory").style.display="block";
            document.getElementById("viewByProductName").style.display="none";
            document.getElementById("managePrices").style.display="none";
            document.getElementById("restockProducts").style.display="none";
        }
        if(id=="viewByProductName"){
            document.getElementById("adminHome").style.display = "none";
            document.getElementById("viewByCategory").style.display="none";
            document.getElementById("viewByProductName").style.display="block";
            document.getElementById("managePrices").style.display="none";
            document.getElementById("restockProducts").style.display="none";
        }
        if(id=="managePrices"){
            document.getElementById("adminHome").style.display = "none";
            document.getElementById("viewByCategory").style.display="none";
            document.getElementById("viewByProductName").style.display="none";
            document.getElementById("managePrices").style.display="block";
            document.getElementById("restockProducts").style.display="none";
        }
        if(id=="restockProducts"){
            document.getElementById("adminHome").style.display = "none";
            document.getElementById("viewByCategory").style.display="none";
            document.getElementById("viewByProductName").style.display="none";
            document.getElementById("managePrices").style.display="none";
            document.getElementById("restockProducts").style.display="block";
        }
        if(id=="adminHome"){
            document.getElementById("adminHome").style.display = "block";
            document.getElementById("viewByCategory").style.display="none";
            document.getElementById("viewByProductName").style.display="none";
            document.getElementById("managePrices").style.display="none";
            document.getElementById("restockProducts").style.display="none";
        }
    }

    function selectCategory(){
        //first delete previous data on table
        

        let selected = document.getElementById("categories").options.selectedIndex;
       // alert(selected);
        if(selected<10){
            selectedClass = "AkodCat0"+selected;
        }
        else{
            selectedClass = "AkodCat" + selected;
        }
        //alert (selectedClass);
        categoryClass = document.getElementsByClassName(selectedClass);
        table = document.getElementById("viewProduct"); //alert(table.rows.length);

        //alert(table.rows.length);
        while(table.rows.length>1){
            //alert("deleting rows");
            document.getElementById("viewProduct").deleteRow(1);
        }
        document.getElementById("totalProducts").innerHTML = "";

        
        //populate with new data
        let r = 0;
        for(i = 0; i<=categoryClass.length; i++){
            
            r++;
           row = table.insertRow(r);
           row.setAttribute("id",r);
           
           //sno = row.insertCell(0);
/*           let sno = document.createElement("td");
           sno.innerHTML = r; 
           row.appendChild(sno); */
           
           
           //brand = row.insertCell(1);
           brand = document.createElement("td");
           brand.innerHTML = categoryClass[i].getAttribute("brand");
           row.appendChild(brand);

           //product = row.insertCell(2);
           product = document.createElement("td");
           product.innerHTML = categoryClass[i].value;
           row.append(product);

           //descr = row.insertCell(3);
           descr = document.createElement("td");
           descr.innerHTML = categoryClass[i].getAttribute("descr");
           row.appendChild(descr);

           //netweight = row.insertCell(4);
           netweight = document.createElement("td");
           netweight.innerHTML = categoryClass[i].getAttribute("netweight");
           row.appendChild(netweight);

           //whole = row.insertCell(5);
           whole = document.createElement("td");
           whole.innerHTML = categoryClass[i].getAttribute("whole");
           row.appendChild(whole);

           //retail = row.insertCell(6);
           retail = document.createElement("td");
           retail.innerHTML = categoryClass[i].getAttribute("retail");
           row.appendChild(retail);

           //alert("Stock Level: "+categoryClass[i].getAttribute("stockLevel"))  ;

           stock = document.createElement("td");
           stock.innerHTML = categoryClass[i].getAttribute("stockLevel") +" "+ categoryClass[i].getAttribute("stockUnit");
           row.appendChild(stock);

           table.appendChild(row);
           
           document.getElementById("totalProducts").innerHTML = "Total Number of Products in Category: " + (table.rows.length - 1).toString();
        }

    }

    function showProductDetails(){
        //alert("I am working now");
       let selector = document.getElementById("selectedProduct").options.selectedIndex; //alert(selector);
        let selectedId = "product" + selector;// alert(selectedId);
        let holder = document.getElementById(selectedId);
        let imageName = holder.value;
        let imgSrc = "assets/images/productlist/" + imageName +".jpg";
        //alert(imgSrc);
        document.getElementById("productImage").src = imgSrc;

        document.getElementById("txtProductName").value = holder.getAttribute("productName");
        document.getElementById("txtProductBrand").value = holder.getAttribute("productBrand");
        document.getElementById("txtWholeSale").value = holder.getAttribute("wholeSale");
        document.getElementById("txtRetailSale").value = holder.getAttribute("retailSale");
        document.getElementById("txtStockValue").value = holder.getAttribute("stockValue");
        document.getElementById("txtProductNetWeight").value = holder.getAttribute("netweight");

/*        if(selector==0){
            document.getElementById("prodDescrRow").style.display=="none";
        }
        else{
            document.getElementById("prodDescrRow").style.display=="block";
        } */
        
    }

    function managePrices(){
        let id = "price" + document.getElementById("productPrices").options.selectedIndex; 
        document.getElementById("txtoldwholesaleprice").value= document.getElementById(id).getAttribute("price_wholeSale"); 
        document.getElementById("txtoldretailsaleprice").value = document.getElementById(id).getAttribute("price_retailSale");
        document.getElementById("selectedProductId").value = document.getElementById(id).value;
        
        alert(document.getElementById("selectedProductId").value);
    }
    function loadPage(){
      let status = sessionStorage.getItem("user");
      let userType=sessionStorage.getItem("userType");
      //alert(status);
      if (status==null){
        //alert(status);
        document.getElementById("loggedin").style.display = "inline";
        document.getElementById("loggedout").style.display = "none";
        document.getElementById("logged-in-user").innerHTML = "";
      }
      else{
        //alert(status);
        document.getElementById("loggedin").style.display = "none";
        document.getElementById("loggedout").style.display = "inline";
        //document.getElementById("logged-in-user").style.display = "block";
      }
      if(userType=="Developer"){
          //alert(sessionStorage.getItem("userType"));
          document.getElementById("manage-users").style.display="inline";
          document.getElementById("manage-products").style.display="inline";
        }
        else{
          //alert(sessionStorage.getItem("userType"));
          document.getElementById("manage-users").style.display="none";
          document.getElementById("manage-products").style.display="none";
        }
    }
    function offloadPage(){
      sessionStorage.clear();
      loadPage();
    }
    function goToMarketPlace(){
      let url = "productlist.php?";
      let emptyUrl = true;

      let cat01 = document.getElementById("AkodCat01");
      let cat02 = document.getElementById("AkodCat02");
      let cat03 = document.getElementById("AkodCat03");
      let cat04 = document.getElementById("AkodCat04");
      let cat05 = document.getElementById("AkodCat05");
      let cat06 = document.getElementById("AkodCat06");
      let cat07 = document.getElementById("AkodCat07");
      let cat08 = document.getElementById("AkodCat08");
      let cat09 = document.getElementById("AkodCat09");
      let cat10 = document.getElementById("AkodCat10");
      let cat11 = document.getElementById("AkodCat11");
      let all = document.getElementById("All");

      if(cat01.checked==true){
        if(emptyUrl== true){url = url + "productCategoryId1=AkodCat01";emptyUrl = false;} else{url = url + "&productCategoryId1=AkodCat01";}
      }
      if(cat02.checked==true){
        if(emptyUrl== true){url = url + "productCategoryId2=AkodCat02";emptyUrl = false;} else{url = url + "&productCategoryId2=AkodCat02";}
      }
      if(cat03.checked==true){
        if(emptyUrl== true){url = url + "productCategoryId3=AkodCat03";emptyUrl = false;} else{url = url + "&productCategoryId3=AkodCat03";}
      }
      if(cat04.checked==true){
        if(emptyUrl== true){url = url + "productCategoryId4=AkodCat04";emptyUrl = false;} else{url = url + "&productCategoryId4=AkodCat04";}
      }
      if(cat05.checked==true){
        if(emptyUrl== true){url = url + "productCategoryId5=AkodCat05";emptyUrl = false;} else{url = url + "&productCategoryId5=AkodCat05";}
      }
      if(cat06.checked==true){
        if(emptyUrl== true){url = url + "productCategoryId6=AkodCat06";emptyUrl = false;} else{url = url + "&productCategoryId6=AkodCat06";}
      }
      if(cat07.checked==true){
        if(emptyUrl== true){url = url + "productCategoryId7=AkodCat07";emptyUrl = false;} else{url = url + "&productCategoryId7=AkodCat07";}
      }
      if(cat08.checked==true){
        if(emptyUrl== true){url = url + "productCategoryId8=AkodCat08";emptyUrl = false;} else{url = url + "&productCategoryId8=AkodCat08";}
      }
      if(cat09.checked==true){
        if(emptyUrl== true){url = url + "productCategoryId9=AkodCat09";emptyUrl = false;} else{url = url + "&productCategoryId9=AkodCat09";}
      }
      if(cat10.checked==true){
        if(emptyUrl== true){url = url + "productCategoryId10=AkodCat10";emptyUrl = false;} else{url = url + "&productCategoryId10=AkodCat10";}
      }
      if(cat11.checked==true){
        if(emptyUrl== true){url = url + "productCategoryId11=AkodCat11";emptyUrl = false;} else{url = url + "&productCategoryId11=AkodCat11";}
      }

      window.open(url);
    }

    function checkAll(){
      let cat01 = document.getElementById("AkodCat01");
      let cat02 = document.getElementById("AkodCat02");
      let cat03 = document.getElementById("AkodCat03");
      let cat04 = document.getElementById("AkodCat04");
      let cat05 = document.getElementById("AkodCat05");
      let cat06 = document.getElementById("AkodCat06");
      let cat07 = document.getElementById("AkodCat07");
      let cat08 = document.getElementById("AkodCat08");
      let cat09 = document.getElementById("AkodCat09");
      let cat10 = document.getElementById("AkodCat10");
      let cat11 = document.getElementById("AkodCat11");
      let all = document.getElementById("All");

      if(all.checked==true){
        cat01.checked = true;cat02.checked = true;cat03.checked = true;cat04.checked = true;
        cat05.checked = true;cat06.checked = true;cat07.checked = true;cat08.checked = true;
        cat09.checked = true;cat10.checked = true;cat11.checked = true;
      }
      else{
        cat01.checked = false;cat02.checked = false;cat03.checked = false;cat04.checked = false;
        cat05.checked = false;cat06.checked = false;cat07.checked = false;cat08.checked = false;
        cat09.checked = false;cat10.checked = false;cat11.checked = false;
      }
    }
   function getUserDetails(){
      
     
    } 

    function logout(){
      document.getElementById("username").value = "";
      document.getElementById("phone").value = "";
      document.getElementById("email").value = "";
      document.getElementById("userType").value = "";
      document.getElementById("fullName").value = "";

      document.getElementById("login").style.display = "block";
      document.getElementById("logout").style.display = "none";
    }

    

</script>
</body>
</html>