<?php
    include_once("assets/database/connectdb.php");
    include ("assets/database/databaseconnection.php");
?>
<!DOCTYPE html>
<html lang="en">

<head>
<!-- Meta -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="author" content="">
<meta name="keywords" content="MediaCenter, Template, eCommerce">
<meta name="robots" content="all">
<title>AKOD TRADING ENTERPRISE | Cereals | Mayonnaise | Grains | Flour Meals | Energy Food Drinks | Vegetable Oil | Flavours | Noodles | Sugar </title>

<!-- Bootstrap Core CSS -->
<link rel="stylesheet" href="assets/css/bootstrap.min.css">

<!-- Customizable CSS -->
<link rel="stylesheet" href="assets/css/main.css">
<link rel="stylesheet" href="assets/css/blue.css">
<link rel="stylesheet" href="assets/css/owl.carousel.css">
<link rel="stylesheet" href="assets/css/owl.transitions.css">
<link rel="stylesheet" href="assets/css/animate.min.css">
<link rel="stylesheet" href="assets/css/rateit.css">
<link rel="stylesheet" href="assets/css/bootstrap-select.min.css">
<link rel="stylesheet" href="assets/css/login.css">
<!--<link rel="stylesheet" href="assets/css/register.css"> -->

<!-- Icons/Glyphs -->
<link rel="stylesheet" href="assets/css/font-awesome.css">

<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Barlow:200,300,300i,400,400i,500,500i,600,700,800" rel="stylesheet">
<link href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,700' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,600italic,700,700italic,800' rel='stylesheet' type='text/css'>
<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
</head>

<body class="cnt-home" onload="loadPage();">

<!--- header -->
<?php 
    include('src/header.php');

?>

<!--- end header -->
<div class="body-content outer-top-vs" id="top-banner-and-menu">
  <div class="container">
    <div class="row"> 
      <!-- ============================================== SIDEBAR ============================================== -->
      <div class="col-xs-12 col-sm-12 col-md-3 sidebar" style="height:2600px;"> 
        
        <!-- ================================== TOP NAVIGATION ================================== -->
        <div class="side-menu animate-dropdown outer-bottom-xs">
          <div class="head" style="color: #fff !important;"><i class="icon fa fa-align-justify fa-fw"></i> Categories</div>
          <nav class="yamm megamenu-horizontal">
            <ul class="nav">
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira" aria-hidden="true"></i>Select All
              <input type = "checkbox" name = "All" id="All" style="float:right; margin-right:5px;" onclick = "checkAll();">
            </li>
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira" aria-hidden="true"></i>Grains & Cereals
              <input type = "checkbox" name = "AkodCat01" id="AkodCat01" style="float:right; margin-right:5px;">
            </li>
              <!-- /.menu-item -->
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira"></i>Vegetable Oil
              <input type = "checkbox" name = "AkodCat02" id="AkodCat02" style="float:right; margin-right:5px;"></li>
              <!-- /.menu-item -->
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira"></i>Seasonings & Flavours
              <input type = "checkbox" name = "AkodCat03" id="AkodCat03" style="float:right; margin-right:5px;"></li>
              <!-- /.menu-item -->
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira"></i>Pastas & Noodles
              <input type = "checkbox" name = "AkodCat04" id="AkodCat04" style="float:right; margin-right:5px;"></li>
              <!-- /.menu-item -->
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira"></i>Tomatoes Pastes & Mixes
              <input type = "checkbox" name = "AkodCat05" id="AkodCat05" style="float:right; margin-right:5px;"></li>
              <!-- /.menu-item -->
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira"></i>Energy Food Drinks
              <input type = "checkbox" name = "AkodCat06" id="AkodCat06" style="float:right; margin-right:5px;"></li>
              <!-- /.menu-item -->
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira"></i>Flour Meals
              <input type = "checkbox" name = "AkodCat07" id="AkodCat07" style="float:right; margin-right:5px;"></li>
                <!-- /.menu-item -->
                
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira"></i>Pasteries & Oven Products
              <input type = "checkbox" name = "AkodCat08" id="AkodCat08" style="float:right; margin-right:5px;"></li>
              <!-- /.menu-item -->
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira"></i>Frozen Products
              <input type = "checkbox" name = "AkodCat09" id="AkodCat09" style="float:right; margin-right:5px;"></li>
              <!-- /.menu-item -->
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira"></i>Sugars & Mayonnaise
              <input type = "checkbox" name = "AkodCat10" id="AkodCat10" style="float:right; margin-right:5px;"></li>
              <!-- /.menu-item -->
              <li class="dropdown menu-item" style="margin:10px;"><i class="icon fa fa-envira"></i>Live Poultry/Goats/Cows
              <input type = "checkbox" name = "AkodCat11" id="AkodCat11" style="float:right; margin-right:5px;"></li>
              <!-- /.menu-item -->
              <li><button type = "button" onclick="goToMarketPlace()">Proceed With Purchses</button</li>
              
            </ul>
            <!-- /.nav --> 
          </nav>
          <!-- /.megamenu-horizontal --> 
        </div>
        <!-- /.side-menu --> 
        <!-- ================================== TOP NAVIGATION : END --> 
        
        <!-- ============================================== HOT DEALS  -->
        <div class="sidebar-widget hot-deals outer-bottom-xs">
          <h3 class="section-title">Hot deals</h3>
          <div class="owl-carousel sidebar-carousel custom-carousel owl-theme outer-top-ss">
            <?php
                
                $sql0 = "select * from producttbl where productCatId = 'AkodCat11'";

                if($result0 = $conn->query($sql0)){
                  while($row = $result0->fetch_assoc()){
                    $img_name1 = "assets/images/productlist/".$row["productId"].".jpg"; //echo $img_name1;
                    $img_name2 = "assets/images/productlist/".$row["productId"]."_1.jpg"; //echo $img_name2;
                    $productName = $row["BrandName"]." ".$row["ProductName"];
                    $productDescription = $row["ProductDescription"];
                    $wholeSalePrice = $row["WholeSalePrice"];
                    $retailSalePrice = $row["RetailSalePrice"]; //echo "Price: ".$retailSalePrice;
            ?>
            <div class="item">
              <div class="products">
                <div class="hot-deal-wrapper">
                  <div class="image"> 
                  <a href="#">
                      <img src= "<?php echo $img_name1; ?>" alt=""> 
                      <img src= "<?php echo $img_name2; ?>" alt="" class="hover-image">
                  </a>
                  </div>
                </div>
                <!-- /.hot-deal-wrapper -->
                
                <div class="product-info text-left m-t-20">
                  <h3 class="name"><a href="detail.html"><?php echo $productName."<br>".$productDescription ?></a></h3>
                  <div class="rating rateit-small"></div>
                  <div class="product-price"> 
                    <span class="price">
                        <?php echo "WholeSale Price: &#8358;".$wholeSalePrice."<br> Retail Price: &#8358;".$retailSalePrice; ?> 
                    </span> 
                    <span class="price-before-discount"></span> 
                  </div>
                  <!-- /.product-price --> 
                  
                </div>
                <!-- /.product-info -->
                
                <div class="cart clearfix animate-effect">
                  <div class="action">
                    <div class="add-cart-button btn-group">
                      <button class="btn btn-primary icon" data-toggle="dropdown" type="button"> <i class="fa fa-shopping-cart"></i> </button>
                      <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                    </div>
                  </div>
                  <!-- /.action --> 
                </div>
                <!-- /.cart --> 
              </div>
            </div>
            <?php 
                  }
              } 
            ?>
          </div>
         <!--  /.sidebar-widget -->
        </div> 
        <!-- ============================================== HOT DEALS: END --> 
        
        <!-- ============================================== SPECIAL OFFER  -->
        
        <div class="sidebar-widget outer-bottom-small">
          <h3 class="section-title">Special Offer</h3>
          <div class="sidebar-widget-body outer-top-xs">
            <div class="owl-carousel sidebar-carousel special-offer custom-carousel owl-theme outer-top-xs">
              <?php
                    $sql = "select * from categorytbl";
                    $result = $conn->query($sql);

                    if($result->num_rows>0){
                      while($rows = $result->fetch_assoc()){
                          $thiscategory = $rows["ProductCatId"];
                          $prodCat = $rows["CategoryName"];
                          $sql1 = "select * from producttbl where productCatId = '$thiscategory'";
                          $result1 = $conn->query($sql1);

                          if($result1->num_rows>0){
                            while($rows1 = $result1->fetch_assoc()){
                              $prodName = $rows1["ProductName"];
                              $prodPrice = $rows1["RetailSalePrice"];
              ?>
                              <div class="item">
                                <div class="products special-product">
                                  <div class="product">
                                    <div class="product-micro">
                                      <div class="row product-micro-row">
                                        <div class="col col-xs-5">
                                          <div class="product-image">
                                            <div class="image"> <a href="productlist.php?productCategoryId=<?php echo $thisCategory; ?>"> <img src="assets/images/products/p5.jpg" alt=""> </a> </div>
                                            <!-- /.image --> 
                                            
                                          </div>
                                          <!-- /.product-image --> 
                                        </div>
                                        <!-- /.col -->
                                        <div class="col col-xs-7">
                                          <div class="product-info">
                                            <h3 class="name"><a href="productlist.php?productCategoryId=<?php echo $thisCategory ?>"><?php echo $prodName; ?></a></h3>
                                            <div class="rating rateit-small"></div>
                                            <div class="product-price"> <span class="price"> &#8358;<?php echo $prodPrice ?> </span> </div>
                                            <!-- /.product-price --> 
                                            
                                          </div>
                                        </div>
                                        <!-- /.col --> 
                                      </div>
                                      <!-- /.product-micro-row --> 
                                    </div>
                                    <!-- /.product-micro --> 
                                    
                                  </div>
                                  
                                </div>
                              </div>
              <?php
                        }
                      }
                    }
                  }
              ?>
              
            </div>
          </div>
          <!-- /.sidebar-widget-body --> 
        </div>
        <!-- /.sidebar-widget --> 
        <!-- ============================================== SPECIAL OFFER : END --> 
        <!-- ============================================== PRODUCT TAGS ============================================== -->
        <div class="sidebar-widget product-tag">
          <h3 class="section-title">Product tags</h3>
          <div class="sidebar-widget-body outer-top-xs">
            <div class="tag-list"> 
              <?php
                $sql = "select * from categorytbl";
                $result = $conn->query($sql);

                if($result->num_rows > 0){
                  while($rows = $result->fetch_assoc()){
                      $prodCatId = $rows["ProductCatId"];
                      $prodCatName = $rows["CategoryName"];
                      ?>
                      <a class="item" title="<?php echo $prodCatName ?>" href="productlist.php?productCategoryId1=<?php echo $prodCatId ?>"><?php echo $prodCatName?></a>
                  <?php
                  }
                }
              ?>
            </div>
            <!-- /.tag-list --> 
          </div>
          <!-- /.sidebar-widget-body --> 
        </div>
        <!-- /.sidebar-widget --> 
        <!-- ============================================== PRODUCT TAGS : END ============================================== --> 
        <!-- ============================================== SPECIAL DEALS ============================================== -->
        
        <div class="sidebar-widget outer-bottom-small">
          <h3 class="section-title">Special Deals</h3>
          <div class="sidebar-widget-body outer-top-xs">
            <div class="owl-carousel sidebar-carousel special-offer custom-carousel owl-theme outer-top-xs">
              <div class="item">
                <div class="products special-product">
                  <?php
                      $sql = "select * from categorytbl";
                      $result = $conn->query($sql);
                      
                      if($result->num_rows > 0){
                          while($rows = $result->fetch_assoc()){
                            
                              $prodCatId = $rows["ProductCatId"];
                              $prodCatName = $rows["CategoryName"];

                              $sql1 = "select * from producttbl where productCatId = '$prodCatId'";
                              $result1 = $conn->query($sql1);
                              if($result1->num_rows > 0){
                                  $i = 0;
                                  while($rows1 = $result1->fetch_assoc()){ 
                                      $i++;
                                      $prodName = $rows1["ProductName"];
                                      $imagename = $rows1["productId"].".jpg";
                                      $prodPrice = $rows1["RetailSalePrice"];
                                  ?>
                                        <div class="product">
                                            <div class="product-micro">
                                              <div class="row product-micro-row">
                                                <div class="col col-xs-5">
                                                  <div class="product-image">
                                                    <div class="image"> <a href="productlist.php?productCategoryId=<?php echo $prodCatId ?>"> <img src="assets/images/products/p10.jpg" alt=""> </a> </div>
                                                    <!-- /.image --> 
                                                    
                                                  </div>
                                                  <!-- /.product-image --> 
                                                </div>
                                                <!-- /.col -->
                                                <div class="col col-xs-7">
                                                  <div class="product-info">
                                                    <h3 class="name"><a href="productlist.php?productCategoryId=<?php echo $prodCatId ?>"><?php echo $prodCatName ?></a></h3>
                                                    <div class="rating rateit-small"></div>
                                                    <div class="product-price"> <span class="price"> &#8358;<?php echo $prodPrice ?> </span> </div>
                                                    <!-- /.product-price --> 
                                                    
                                                  </div>
                                                </div>
                                                <!-- /.col --> 
                                              </div>
                                              <!-- /.product-micro-row --> 
                                            </div>
                                            <!-- /.product-micro --> 
                                            
                                          </div>
                            <?php  
                                  if($i >= 1){
                                      break;
                                  } 
                                }
                              }
                          }
                      }
                  ?>
                </div>
              </div>
              
            </div>
          </div>
          <!-- /.sidebar-widget-body --> 
        </div>
        <!-- /.sidebar-widget --> 
        <!-- ============================================== SPECIAL DEALS : END --> 

        
        <!-- ============================================== Testimonials: END ============================================== -->
        
        
      </div>
      <!-- /.sidemenu-holder --> 
      <!-- ============================================== SIDEBAR : END ============================================== --> 
      
      <!-- ============================================== CONTENT ============================================== -->
      <div class="col-xs-12 col-sm-12 col-md-9 homebanner-holder" style="height:2600px; overflow-y:auto;"> 
        <!-- ========================================== SECTION – HERO ========================================= -->
        
        <div id="hero"  style="background-color:blue">
          <div id="owl-main" class="owl-carousel owl-inner-nav owl-ui-sm">
            <div class="item" style="background-image: url(assets/images/sliders/01.jpg); background-size:50%;
            background-repeat:no-repeat;background-position:bottom right">
              <div class="container-fluid">
                <div class="caption bg-color vertical-center text-left">
                  <div class="slider-header fadeInDown-1">Flour Meals</div>
                  <div class="big-text fadeInDown-1">Golden Penny Semovita</div>
                  <div class="excerpt fadeInDown-2 hidden-xs"> <span>We stock all brands and sizes of quality flour meals</span> </div>
                  <div class="button-holder fadeInDown-3"> 
                    <a href="productlist.php?productCategoryId1=AkodCat07" class="btn-lg btn btn-uppercase btn-primary shop-now-button">
                      Shop Now
                    </a> 
                  </div>
                </div>
                <!-- /.caption --> 
              </div>
              <!-- /.container-fluid --> 
            </div>
            <!-- /.item -->
            
            <div class="item" style="background-image: url(assets/images/sliders/02.jpg);background-size:50%;
            background-repeat:no-repeat;background-position:bottom right">
              <div class="container-fluid">
                <div class="caption bg-color vertical-center text-left">
                  <div class="slider-header fadeInDown-1">Energy Food Drinks</div>
                  <div class="big-text fadeInDown-1"> Nestle Milo </div>
                  <div class="excerpt fadeInDown-2 hidden-xs"> <span>Check out our stock of Variety of Energy Food Drinks</span> </div>
                  <div class="button-holder fadeInDown-3"> 
                    <a href="productlist.php?productCategoryId1=AkodCat06" class="btn-lg btn btn-uppercase btn-primary shop-now-button">
                      Shop Now
                    </a> 
                  </div>
                </div>
                <!-- /.caption --> 
              </div>
              <!-- /.container-fluid --> 
            </div>
            <div class="item" style="background-image: url(assets/images/sliders/04.png);background-size:50%;
            background-repeat:no-repeat;background-position:bottom right">
              <div class="container-fluid">
                <div class="caption bg-color vertical-center text-left">
                  <div class="slider-header fadeInDown-1">Noodles And Pastas</div>
                  <div class="big-text fadeInDown-1"> Instant Noodles </div>
                  <div class="excerpt fadeInDown-2 hidden-xs"> <span>Indomie, Honeywell etc</span> </div>
                  <div class="button-holder fadeInDown-3"> 
                    <a href="productlist.php?productCategoryId1=AkodCat04" class="btn-lg btn btn-uppercase btn-primary shop-now-button">
                      Shop Now
                    </a> 
                  </div>
                </div>
                <!-- /.caption --> 
              </div>
              <!-- /.container-fluid --> 
            </div>
            <!-- /.item --> 
            
          </div>
          <!-- /.owl-carousel --> 
        </div>
        
        <!-- ========================================= SECTION – HERO : END --> 
        
        <?php
            $sql_categories = "select * from categorytbl";
            $result_categories = $conn->query($sql_categories);
            if($result_categories->num_rows>0){
              while($rows_categories = $result_categories->fetch_assoc()){
                $category = $rows_categories["ProductCatId"];
                $categoryName = $rows_categories["CategoryName"];
        ?>
                <!-- ============================================== SCROLL TABS -->

                <div id="product-tabs-slider" class="scroll-tabs outer-top-vs" style="background-color:lightblue;">
                    <div class="more-info-tab clearfix ">
                        <h3 class="new-product-title pull-left"><?php echo $categoryName; ?></h3>
                    </div>
          
                    <div class="tab-content outer-top-xs">
                        <div class="tab-pane in active" id="all">
                            <div class="product-slider" style="margin-right:10px;">
                                <div class="owl-carousel home-owl-carousel custom-carousel owl-theme">
                                   <?php
                                      $sql_products = "select * from producttbl where productCatId = '$category'";
                                      $result_products = $conn->query($sql_products);
                      
                                      if($result_products->num_rows>0){
                                          while($rows_products = $result_products->fetch_assoc()){
                                                $imageName = "assets/images/productlist/".$rows_products["productId"].".jpg";
                                                $productName = $rows_products["BrandName"]. " ". $rows_products["ProductName"];
                                                $productDescription = $rows_products["ProductDescription"];
                                                $productNetWeight = $rows_products["ProductNetWeight"];
                                                $wholeSalePrice = $rows_products["WholeSalePrice"];
                                                $retailSalePrice = $rows_products["RetailSalePrice"];
                                  ?>
                                                <div class="item item-carousel" style = "width: 100%;">
                                                      <div class="products">
                                                          <div class="product">
                                                              <div class="product-image">
                                                                  <div class="image"> 
                                                                      <a href="#">
                                                                          <img src="<?php echo $imageName; ?>" alt="" style="width:100%;"> 
                                                                          <!--<img src="assets/images/products/cereals1_hover.jpg" alt="" class="hover-image">-->
                                                                      </a> 
                                                                  </div>
                                                                  <!-- /.image -->
                          
                                                                  <!-- <div class="tag new"><span>new</span></div> -->
                                                               </div>
                                                                <!-- /.product-image -->
                        
                                                                <div class="product-info text-left">
                                                                      <h3 class="name"><a href="detail.html"><?php echo $productName ."<br>$productDescription <br> $productNetWeight"; ?> </a></h3>
                                                                      <div class="rating rateit-small"></div>
                                                                      <div class="description"></div>
                                                                      <hr>
                                                                      <div class="product-price"> 
                                                                          <span class="price"> <?php echo "Whole Sale Price: &#8358; $wholeSalePrice <br>
                                                                              Retail Sale Price: &#8358; $retailSalePrice"  ?></span> 
                                                                          <!-- <span class="price-before-discount">&#8358; 800</span> -->
                                                                      </div>
                                                                      <!-- /.product-price --> 
                          
                                                                </div>
                                                                <!-- /.product-info -->
                                                                <div class="cart clearfix animate-effect">
                                                                    <div class="action">
                                                                        <ul class="list-unstyled">
                                                                            <li class="add-cart-button btn-group">
                                                                                <button data-toggle="tooltip" class="btn btn-primary icon" type="button" title="Add Cart"> <i class="fa fa-shopping-cart"></i> </button>
                                                                                <button class="btn btn-primary cart-btn" type="button">Add to cart</button>
                                                                            </li>
                                                                            <li class="lnk wishlist"> <a data-toggle="tooltip" class="add-to-cart" href="detail.html" title="Wishlist"> <i class="icon fa fa-heart"></i> </a> </li>
                                                                            <li class="lnk"> <a data-toggle="tooltip" class="add-to-cart" href="detail.html" title="Compare"> <i class="fa fa-signal" aria-hidden="true"></i> </a> </li>
                                                                        </ul>
                                                                     </div>
                                                                      <!-- /.action --> 
                                                                   </div>
                                                                    <!-- /.cart --> 
                                                                </div>
                                                                  <!-- /.product --> 
                      
                                                            </div>
                                                                <!-- /.products --> 
                                                      </div> <!-- /.item -->
                                                            <?php
                                                                   }
                                                                }
                                                                else{
                                                                  echo "No Product On This Category";
                                                                }
                                                            ?>
                                                            <!-- /.item -->
                  
                                                            <!-- /.tab-content --> 
                                                </div>
                                          </div>
                                    </div>
                                </div>
                          </div>
                                                        <?php
                                                            }

                                                          }
                                                          else{
                                                            echo $conn->error;
                                                          }
                                                        ?>
                                                    
                                                    <!-- /.scroll-tabs --> 
        
      </div>
      <!-- /.homebanner-holder --> 
    </div>
    <!-- /.row --> 
    
    <!-- ============================================== BRANDS CAROUSEL : END ============================================== --> 
  </div>
  <!-- /.container --> 
</div>
<!-- /#top-banner-and-menu --> 

        <!-- ============================================== INFO BOXES ============================================== -->
        <div class="row our-features-box">
     <div class="container">
      <ul>
        <li>
          <div class="feature-box">
            <div class="icon-truck" style="font-size:40px; color:blue"></div>
            <div class="content-blocks">We provide logistic support worldwide</div>
          </div>
        </li>
        <li>
          <div class="feature-box">
            <div class="icon-support" style="font-size:40px; color:blue"></div>
            <div class="content-blocks">call 
              +234 818 977 0044</div>
          </div>
        </li>
     <!--   <li>
          <div class="feature-box">
            <div class="icon-money"></div>  
            <div class="content-blocks">Money Back Guarantee</div>
          </div>
        </li>
        <li>
          <div class="feature-box">
            <div class="icon-return"></div>
            <div class="content">30 days return</div>
          </div>
        </li> -->
        
      </ul>
    </div>
  </div>
        <!-- /.info-boxes --> 
        <!-- ============================================== INFO BOXES : END ============================================== --> 

<!-- ============================================================= FOOTER ============================================================= -->
<?php include('src/footer.php');?>
<!-- ============================================================= FOOTER : END============================================================= --> 

<!-- For demo purposes – can be removed on production --> 

<!-- For demo purposes – can be removed on production : End --> 

<!-- JavaScripts placed at the end of the document so the pages load faster --> 

</script>
<script src="assets/js/jquery-1.11.1.min.js"></script> 
<script src="assets/js/bootstrap.min.js"></script> 
<script src="assets/js/bootstrap-hover-dropdown.min.js"></script> 
<script src="assets/js/owl.carousel.min.js"></script> 
<script src="assets/js/echo.min.js"></script> 
<script src="assets/js/jquery.easing-1.3.min.js"></script> 
<script src="assets/js/bootstrap-slider.min.js"></script> 
<script src="assets/js/jquery.rateit.min.js"></script> 
<script src="assets/js/lightbox.min.js"></script> 
<script src="assets/js/bootstrap-select.min.js"></script> 
<script src="assets/js/wow.min.js"></script> 
<script src="assets/js/scripts.js"></script>
<script src="assets/js/loadPage.js"></script>
</body>

</html>